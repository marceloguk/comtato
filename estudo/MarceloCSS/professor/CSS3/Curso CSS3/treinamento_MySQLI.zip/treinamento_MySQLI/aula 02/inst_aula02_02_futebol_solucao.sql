﻿   /*
   
   Crie um database FUTEBOL:
 ___________________________	 ___________________________	 ___________________________
|							|	|							|	|							|
|		TIMES				|	|		TECNICOS		    |	|		JOGADORES			|
|							|	|							|	|							|
|___________________________|	|___________________________|	|___________________________|
|							|	|							|	|							|
|    TIM_COD	int			|	|    TEC_COD	int			|	|    JOG_COD	int			|
|    TIM_NOME	varchar(50)	|	|    TEC_NOME	varchar(50)	|	|    JOG_NOME	varchar(50)	|
|    TIM_FUND	date	    |	|    TIM_COD	int			|	|    TIM_COD	int			|
|							|	|							|	|							|
|___________________________|	|___________________________|	|___________________________|

	Insira os times, técnicos e jogadores abaixo:

	Times:
	Santos
	Corinthians
	São Paulo
	Palmeiras

	Técnicos:
	Márcio Fernandes - Santos
	Mano Menezes	 - Corinthians
	Muricy Ramalho	 - São Paulo
	Luxemburgo		 - Palmeiras

	Jogadores:
	Kleber Pereira	- Santos
	Ricky			- São Paulo
	Marcos			- Palmeiras
	Acosta			- Corinthians
	Fábio Costa		- Santos
	Rogério Ceni	- São Paulo
	Arouca			- São Paulo

*/






CREATE DATABASE FUTEBOL;

USE FUTEBOL;

CREATE TABLE TIMES (

  TIM_COD  INT(3),
  TIM_NOME VARCHAR(50),
  TIM_FUND DATETIME
);

CREATE TABLE TECNICOS (

  TEC_COD  INT(3),
  TEC_NOME VARCHAR(50),
  TIM_COD  INT(3)

);

CREATE TABLE JOGADORES (

  JOG_COD  INT(3),
  JOG_NOME VARCHAR(50),
  TIM_COD  INT(3)

);

SELECT * FROM TIMES;
SELECT * FROM TECNICOS;
SELECT * FROM JOGADORES;



-- INSERT DECLARATÓRIO
INSERT INTO TIMES (TIM_COD , TIM_NOME , TIM_FUND) VALUES ('1' , 'SANTOS' , '1895/12/20');

-- INSERT POSICIONAL
INSERT INTO TIMES VALUES ('2' , 'CORINTHIANS' , '1910/10/24');

INSERT INTO TIMES VALUES ('3' , 'SÃO PAULO' , '1923/10/24') , ('4' , 'Palmeiras' , null);



INSERT INTO TECNICOS VALUES
  ( 1 ,	'Márcio Fernandes' , 1),
	(2 , 'Mano Menezes' , 2 ),
	(3 , 'Muricy Ramalho' , 3 ),
	( 4 ,'Luxemburgo' , 4);



INSERT INTO JOGADORES VALUES
	(1 , 'Kleber Pereira' , 1),
	(2 , 'Ricky' , 3),
	(3 , 'Marcos' , 4),
	(4 , 'Acosta' , 2),
	(5 , 'Fábio Costa' , 1),
	(6 , 'Rogério Ceni' , 3),
	(7 , 'Arouca' , 2);
