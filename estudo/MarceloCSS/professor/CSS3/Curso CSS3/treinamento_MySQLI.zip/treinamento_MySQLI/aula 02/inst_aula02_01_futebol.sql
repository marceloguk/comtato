   /*
   
   Crie um database FUTEBOL:
 ___________________________	 ___________________________	 ___________________________
|							|	|							|	|							|
|		TIMES				|	|		TECNICOS		    |	|		JOGADORES			|
|							|	|							|	|							|
|___________________________|	|___________________________|	|___________________________|
|							|	|							|	|							|
|    TIM_COD	int			|	|    TEC_COD	int			|	|    JOG_COD	int			|
|    TIM_NOME	varchar(50)	|	|    TEC_NOME	varchar(50)	|	|    JOG_NOME	varchar(50)	|
|    TIM_FUND	date	    |	|    TIM_COD	int			|	|    TIM_COD	int			|
|							|	|							|	|							|
|___________________________|	|___________________________|	|___________________________|

	Insira os times, t�cnicos e jogadores abaixo:

	Times:
	Santos
	Corinthians
	S�o Paulo
	Palmeiras

	T�cnicos:
	M�rcio Fernandes - Santos
	Mano Menezes	 - Corinthians
	Muricy Ramalho	 - S�o Paulo
	Luxemburgo		 - Palmeiras

	Jogadores:
	Kleber Pereira	- Santos
	Ricky			- S�o Paulo
	Marcos			- Palmeiras
	Acosta			- Corinthians
	F�bio Costa		- Santos
	Rog�rio Ceni	- S�o Paulo
	Arouca			- S�o Paulo

*/


