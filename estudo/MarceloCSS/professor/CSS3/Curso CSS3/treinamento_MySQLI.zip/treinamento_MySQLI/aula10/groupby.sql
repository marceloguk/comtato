use chocolate;

select 'Cargo' as tabela,
    nome_cargo as nome
from cargo

union all

select 'Funcionario',
    nome_func
from funcionario;


select * from cargo
where cod_cargo in
(select cod_cargo from funcionario);
-- 1,2,3,3,5,5
/****************************************/
use db_cds;

select * from cliente;
select * from conjuge;

select * from cliente
where cod_cli not in
(select cod_cli from conjuge);

select * from funcionario
where cod_func not in
(select cod_func from dependente);


select * from funcionario
where cod_func in
(select cod_func from dependente);


select * from categoria
where cod_cat not in
(select cod_cat from titulo);

select * from gravadora
where cod_grav not in
(select cod_grav from titulo);

select * from funcionario
where cod_func not in
(select cod_func from pedido);


select * from funcionario
where cod_func in
(select cod_func from pedido
where cod_cli in
(select cod_cli from conjuge));

use chocolate;


select * from funcionario
where salario_func = 3000;

use db_cds;
select categoria.nome_cat,
count(titulo.cod_cat) as total
from titulo inner join categoria
on titulo.cod_cat = categoria.cod_cat
group by categoria.nome_cat, titulo.cod_cat;


select c.nome_cat,
count(t.cod_cat) as total
from titulo t inner join categoria c
on t.cod_cat = c.cod_cat
group by c.nome_cat, t.cod_cat;

select g.nome_grav,
count(t.cod_grav) as total
from titulo t inner join gravadora g
on t.cod_grav = g.cod_grav
group by g.nome_grav, t.cod_grav;

select f.nome_func,
count(p.cod_func) as total
from funcionario f inner join pedido p
on f.cod_func = p.cod_func
group by f.nome_func, p.cod_func;

select f.nome_func,
count(d.cod_func) as qtd_dep
from funcionario f inner join dependente d
using(cod_func)
group by f.nome_func, d.cod_func;




