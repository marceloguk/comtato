delimiter $$
create procedure cad_cat
(codigo int, cat varchar(50))
begin
    if exists(select * from categoria
        where nome_cat = cat) then
    select "Essa categoria já existe!"
        as resultado;
    else
    insert into categoria values
    (codigo, cat);
select "Categoria cadastrada com sucesso"
  as resultado;
    end if;
end
$$
delimiter ;
call cad_cat(5,"Samba");