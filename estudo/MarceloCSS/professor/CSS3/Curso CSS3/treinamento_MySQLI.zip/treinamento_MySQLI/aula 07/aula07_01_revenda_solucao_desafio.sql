
use auto_sell;


-- Desafio 1:

-- Execute o select abaixo:

select * from carros;

-- Note que existem 14 carros cadastrados no sistema.

select * from carros
    where car_venda is not null;

-- Note agora que existem 6 carros que foram vendidos.

select * from transacoes where tran_tipo = 'v' ;

-- Embora na tabela carros exista a informa��o que 6 carros foram vendidos, 
-- na tabela de transa��es, constam apenas 3 transa��es de venda.
-- Portanto, h� um erro na consist�ncia dos dados.

-- 08) Liste os carros que n�o possuem transa��o de venda.

-- Resolvendo o problema:
select * from carros
where car_venda is not null;	-- Todos os carros j� vendidos


select * from transacoes
where tran_tipo = 'v';		-- Todas as Transa��es de venda

-- Analisando, conclui-se que faltam os carros 10, 13, 14. Portanto:

-- Resolvendo a quest�o sabendo os ID's dos Carros.
select * from carros where car_id not in (3, 6 ,7)
						and car_venda is not null;


-- Resolvendo a quest�o caso a tabela transa��es tivesse muitos dados
select * from carros where car_id not in
(select car_id from transacoes where tran_tipo = 'v')
			and car_venda is not null;


-- Explicando:

select * from carros				-- Consulta trazendo tudo da tabela carros
		where car_id not in			-- Cl�usula definindo quais ID's n�o devem vir na consulta
		(select car_id from transacoes where tran_tipo = 'v') -- Ao inv�s de definir cada ID que n�o deve aparecer, foi feito um select que traz exatamente essa listagem
		and car_venda is not null;	-- Outra cl�usula de defini��o




-- 09) Corrija a tabela de transa��es, definindo a venda dos autos no sistema.
-- Adote como padr�o: O vendedor respons�vel pela venda desses carros foi o Lindomar;
-- e o cliente respons�vel pela compra dos autos foi o Ricardo Pereira.
-- PS: Obrigatoriamente, ser�o 3 registro inseridos na tabela.

insert transacoes values ( null , 'v',6,10,3);
insert transacoes values ( null , 'v',6,13,3);
insert transacoes values ( null , 'v',6,14,3);



-- Join com + de 2 tabelas:

-- 10) Qual o modelo, montadora e valor do carro mais caro que n�s j� compramos?

select * from modelos;
select * from montadoras;
select * from carros;



 -- Join com 3 tabelas e trazendo TODAS as Colunas

select * from carros c
    inner join  modelos md on md.mod_id = c.mod_id
    inner join  montadoras ma on ma.mon_id = md.mon_id;


-- Organizando e trazendo somente as colunas relevantes

select c.car_placa , md.mod_nome , ma.mon_nome , c.car_custo
    from carros c
    inner join  modelos md on md.mod_id = c.mod_id
    inner join  montadoras ma on ma.mon_id = md.mon_id;


-- Apelidando as Colunas

select c.car_placa Placa,
       md.mod_nome Modelo,
       ma.mon_nome Montadora,
       c.car_custo Valor
    from carros c
    inner join  modelos md on md.mod_id = c.mod_id
    inner join  montadoras ma on ma.mon_id = md.mon_id
       order by c.car_custo desc;



-- Trazendo s� o mais caro!

  select  mo.mod_nome Modelo ,
          mon.mon_nome Montadora ,
          ca.car_custo Valor from montadoras mon
      inner join  modelos mo  on  mo.mon_id = mon.mon_id
      inner join  carros ca   on  mo.mod_id = ca.mod_id
      where ca.car_custo = (select max(car_custo) from carros);




-- Concatenando as Colunas (s� para bagun�ar)

select
       concat('O carro possui a placa ' ,
               c.car_placa,
              ' e modelo: ',
              md.mod_nome ,
              ' e Montadora: ',
              ma.mon_nome ) as 'Frase Bagun�ada',
       c.car_custo Valor
    from carros c
    inner join  modelos md on md.mod_id = c.mod_id
    inner join  montadoras ma on ma.mon_id = md.mon_id
       order by c.car_custo desc;





-- CONCAT --> Concatena STRINGS

  select concat(  'Ol� '   ,   ' Pessoal !' ) as 'Sauda��o';





-- GROUP BY

-- Como contar qtos carros eu tenho sistema por modelo ?

-- Ponto de partida: Placas (carro) e seus respectivos modelos

select c.car_placa , m.mod_nome from carros c
      inner join modelos m on m.mod_id = c.mod_id
      order by m.mod_nome;



-- Contando Placas por Modelo

select count(c.car_placa) as 'Qtd de Carros' ,
       m.mod_nome from carros c
      inner join modelos m on m.mod_id = c.mod_id
      GROUP BY m.mod_nome
      order by m.mod_nome;




-- Contar Modelos por Montadora:

select * from modelos md
      join montadoras mt on mt.mon_id = md.mon_id;


select mt.mon_nome , md.mod_nome from modelos md
      join montadoras mt on mt.mon_id = md.mon_id
      order by mt.mon_nome;



select mt.mon_nome , count(md.mod_nome) from modelos md
      join montadoras mt on mt.mon_id = md.mon_id
      group by mt.mon_nome
      order by mt.mon_nome;


-- ROLL UP --> Pouco Utilizado

select mt.mon_nome , count(md.mod_nome) from modelos md
      join montadoras mt on mt.mon_id = md.mon_id
      group by mt.mon_nome with rollup ;