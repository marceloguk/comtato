



-- 10) Qual o modelo, montadora e valor do carro mais caro que n�s j� compramos?

-- 11) Traga uma lista dos carros � venda, com o seu modelo e montadora.

-- 12) Traga uma lista dos carros no sistema, com o seu modelo, ano, placa e montadora.

-- 13) Quais montadoras possuem carros � venda no sistema ?

-- 14) Qual dos nossos vendedores compra mais carros ?

-- 15) De quem n�s j� compramos carros?

-- 16) Liste todos os carros da montadora FORD j� vendidos.

-- 17) Liste todos os carros da montadora FERRARI � venda.

-- 18) Quantos carros foram vendidos at� o momento?

-- 19) Quantos clientes possuem restri��o de compra ?

-- 20) Liste todos os carros (com o modelo) , definindo seu tipo de combust�vel por extenso (FLEX, Gasolina, etc).

-- 21) Liste todos os carros (com placa, modelo e Montadora) comprados de clientes que possuem restri��o em nosso sistema.

-- 22) Liste todos os carros (com placa, modelo e Montadora) j� vendidos.

-- 23) Calcule qual a margem (%) de lucro na venda de cada carro j� vendido.

/*

	Regras de Neg�cios:

	Qdo ocorre uma venda, cada vendedor recebe 50% do lucro sobre o carro como
	comiss�o de venda.

	Ou seja, se um carro foi comprado por R$10.000,00 e vendido por R$15.000,00
	O vendedor t�m direito a R$ 2.500,00 de comiss�o.


	Baseando-se nisso, resolva abaixo:
*/


-- 24) Qto cada vendedor recebeu de comiss�o em cada venda ?

-- 25) Qto cada vendedor recebeu ao total ?



