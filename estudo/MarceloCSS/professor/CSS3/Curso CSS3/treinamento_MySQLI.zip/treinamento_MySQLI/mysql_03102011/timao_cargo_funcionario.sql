use impacta;
-- ----------------------------------------
create table cargo
(
    cod_cargo int not null,
    nome_cargo  varchar(50) not null,
constraint pk_cargo primary key(cod_cargo),
constraint uq_cargo unique(nome_cargo)
);
-- ----------------------------------------
insert into cargo values
(1,'Presidente'),(2,'Gerente'),
(3,'Supervisor'),(4,'Revisor'),
(5,'Redator');
-- ----------------------------------------
create table funcionario
(
    cod_func int not null,
    cod_cargo   int not null,
    nome_func   varchar(50) not null,
    salario_func    dec(10,2) not null,
    rg_func     varchar(15) not null,
constraint pk_func primary key(cod_func),
constraint fk_func foreign key(cod_cargo)
references cargo(cod_cargo),
constraint ch_func check(salario_func > 0 ),
constraint uq_func unique(rg_func)
);
-- ----------------------------------------
insert into funcionario values
(1,5,'Luís Pereira',3000.00,'27.291.905'),
(2,5,'Antonio Almeida',3000.00,'15.970.247'),
(3,3,'Donizete Ribeiro',2800.00,'27.151.908'),
(4,3,'Gabriela Moura',4700.00,'25.279.145'),
(5,2,'Emílio Duarte',5000.00,'17.278.246'),
(6,1,'Carolina Ferreira',9000.00,'18.154.578');
-- ----------------------------------------
/*
Para montar qualquer join, com duas 
ou duzentas tabelas, basta seguir 
a receita de bolo, descrita a seguir.

Um Join é composto por três partes:

1º O que será exibido?

2º De onde vêm os dados e qual join será 
usado?

3º Onde está o relacionamento?
*/
use impacta;

select funcionario.nome_func,
cargo.nome_cargo
from funcionario inner join cargo
on funcionario.cod_cargo = cargo.cod_cargo;

use db_cds;

select * from titulo;
select * from categoria;
-- -------------------------------------
/*
nome_cd, nome_cat
cod_cat
*/
use db_cds;
-- -------------------------------------
select titulo.nome_cd,
categoria.nome_cat
from titulo inner join categoria
using(cod_cat);
-- -------------------------------------
select * from titulo;
select * from gravadora;
-- -------------------------------------
desc titulo;
-- -------------------------------------
use information_schema;
-- -------------------------------------
show tables;
-- -------------------------------------
select * from referential_constraints
where constraint_schema='db_cds'
and constraint_name='FK_cli';
-- -------------------------------------
use information_schema;
-- -------------------------------------
use db_cds;
delimiter $$
create procedure muitolouca(
banco varchar(100), tabela varchar(100))
begin
    select constraint_name as 'Constraint',
    table_schema as Banco,
    table_name as Tabela,
    Column_Name as 'Coluna Origem',
    referenced_table_name as
    'Tabela Referenciada',
    referenced_column_name as 
    'Coluna Referenciada'
    from information_schema.key_column_usage
    where table_schema= banco
    and table_name= tabela;
end
$$

delimiter ;
-- -------------------------------------
call muitolouca('db_cds','titulo');
-- -------------------------------------
desc titulo;
-- -------------------------------------
select titulo.nome_cd, gravadora.nome_grav 
from titulo inner join gravadora
on titulo.cod_grav = gravadora.cod_grav;
-- -------------------------------------
select database();
-- ---------------------------------------
select gravadora.nome_grav,
titulo.nome_cd, categoria.nome_cat
from gravadora inner join titulo
on gravadora.cod_grav = titulo.cod_grav
inner join categoria 
on titulo.cod_cat = categoria.cod_cat;
-- ---------------------------------------
