CREATE DATABASE  IF NOT EXISTS `db_cds` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_cds`;
-- MySQL dump 10.13  Distrib 5.1.40, for Win32 (ia32)
--
-- Host: localhost    Database: db_cds
-- ------------------------------------------------------
-- Server version	5.5.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria` (
  `Cod_Cat` int(11) NOT NULL,
  `Nome_Cat` varchar(50) NOT NULL,
  PRIMARY KEY (`Cod_Cat`),
  UNIQUE KEY `UQ_Cat` (`Nome_Cat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'MPB'),(3,'Rock Internacional'),(4,'Rock Nacional'),(2,'Trilha Sonora');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artista`
--

DROP TABLE IF EXISTS `artista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artista` (
  `Cod_Art` int(11) NOT NULL,
  `Nome_Art` varchar(100) NOT NULL,
  PRIMARY KEY (`Cod_Art`),
  UNIQUE KEY `UQ_Art` (`Nome_Art`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artista`
--

LOCK TABLES `artista` WRITE;
/*!40000 ALTER TABLE `artista` DISABLE KEYS */;
INSERT INTO `artista` VALUES (3,'Caetano Veloso'),(2,'Gilberto Gil'),(5,'Legião Urbana'),(1,'Marisa Monte'),(4,'Milton Nascimento'),(7,'Rita Lee'),(6,'The Beatles');
/*!40000 ALTER TABLE `artista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `titulo_artista`
--

DROP TABLE IF EXISTS `titulo_artista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `titulo_artista` (
  `Cod_Tit` int(11) NOT NULL,
  `Cod_Art` int(11) NOT NULL,
  PRIMARY KEY (`Cod_Tit`,`Cod_Art`),
  KEY `FK_TA2` (`Cod_Art`),
  CONSTRAINT `FK_TA1` FOREIGN KEY (`Cod_Tit`) REFERENCES `titulo` (`Cod_Tit`),
  CONSTRAINT `FK_TA2` FOREIGN KEY (`Cod_Art`) REFERENCES `artista` (`Cod_Art`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titulo_artista`
--

LOCK TABLES `titulo_artista` WRITE;
/*!40000 ALTER TABLE `titulo_artista` DISABLE KEYS */;
INSERT INTO `titulo_artista` VALUES (1,1),(2,2),(3,2),(4,2),(5,3),(6,4),(7,4),(8,5),(9,6),(10,7);
/*!40000 ALTER TABLE `titulo_artista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `titulo_pedido`
--

DROP TABLE IF EXISTS `titulo_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `titulo_pedido` (
  `Num_Ped` int(11) NOT NULL,
  `Cod_Tit` int(11) NOT NULL,
  `Qtd_CD` int(11) NOT NULL,
  `Val_CD` decimal(10,2) NOT NULL,
  PRIMARY KEY (`Num_Ped`,`Cod_Tit`),
  KEY `FK_TP2` (`Cod_Tit`),
  CONSTRAINT `FK_TP1` FOREIGN KEY (`Num_Ped`) REFERENCES `pedido` (`Num_Ped`),
  CONSTRAINT `FK_TP2` FOREIGN KEY (`Cod_Tit`) REFERENCES `titulo` (`Cod_Tit`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titulo_pedido`
--

LOCK TABLES `titulo_pedido` WRITE;
/*!40000 ALTER TABLE `titulo_pedido` DISABLE KEYS */;
INSERT INTO `titulo_pedido` VALUES (1,1,2,'30.00'),(1,2,3,'20.00'),(2,1,1,'50.00'),(2,2,3,'30.00'),(3,1,2,'40.00'),(4,2,3,'20.00'),(5,1,2,'25.00'),(6,2,3,'30.00'),(6,3,1,'35.00'),(7,4,2,'55.00'),(8,1,4,'60.00'),(9,2,3,'15.00'),(10,7,2,'15.00');
/*!40000 ALTER TABLE `titulo_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cidade`
--

DROP TABLE IF EXISTS `cidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cidade` (
  `Cod_Cid` int(11) NOT NULL,
  `Sigla_Est` char(2) NOT NULL,
  `Nome_Cid` varchar(100) NOT NULL,
  PRIMARY KEY (`Cod_Cid`),
  KEY `FK_Cid` (`Sigla_Est`),
  CONSTRAINT `FK_Cid` FOREIGN KEY (`Sigla_Est`) REFERENCES `estado` (`Sigla_Est`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cidade`
--

LOCK TABLES `cidade` WRITE;
/*!40000 ALTER TABLE `cidade` DISABLE KEYS */;
INSERT INTO `cidade` VALUES (1,'SP','São Paulo'),(2,'SP','Sorocaba'),(3,'SP','Jundiaí'),(4,'SP','Americana'),(5,'SP','Araraquara'),(6,'MG','Ouro Preto'),(7,'ES','Cachoeiro de Itapemirim');
/*!40000 ALTER TABLE `cidade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependente`
--

DROP TABLE IF EXISTS `dependente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dependente` (
  `Cod_Dep` int(11) NOT NULL,
  `Cod_Func` int(11) NOT NULL,
  `Nome_Dep` varchar(100) NOT NULL,
  `Sexo_Dep` char(1) NOT NULL DEFAULT 'M',
  PRIMARY KEY (`Cod_Dep`),
  KEY `FK_Dep` (`Cod_Func`),
  CONSTRAINT `FK_Dep` FOREIGN KEY (`Cod_Func`) REFERENCES `funcionario` (`Cod_Func`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependente`
--

LOCK TABLES `dependente` WRITE;
/*!40000 ALTER TABLE `dependente` DISABLE KEYS */;
INSERT INTO `dependente` VALUES (1,1,'Ana Pereira','F'),(2,1,'Roberto Pereira','M'),(3,1,'Celso Pereira','M'),(4,3,'Brisa Linhares','F'),(5,3,'Mari Sol Linhares','F'),(6,4,'Sonia da Silva','F');
/*!40000 ALTER TABLE `dependente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido` (
  `Num_Ped` int(11) NOT NULL,
  `Cod_Cli` int(11) NOT NULL,
  `Cod_Func` int(11) NOT NULL,
  `Data_Ped` datetime NOT NULL,
  `val_Ped` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`Num_Ped`),
  KEY `FK_Ped1` (`Cod_Cli`),
  KEY `FK_Ped2` (`Cod_Func`),
  CONSTRAINT `FK_Ped1` FOREIGN KEY (`Cod_Cli`) REFERENCES `cliente` (`Cod_Cli`),
  CONSTRAINT `FK_Ped2` FOREIGN KEY (`Cod_Func`) REFERENCES `funcionario` (`Cod_Func`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
INSERT INTO `pedido` VALUES (1,1,2,'2002-05-02 00:00:00','1500.00'),(2,3,4,'2002-05-02 00:00:00','50.00'),(3,4,5,'2002-06-02 00:00:00','100.00'),(4,1,4,'2002-02-03 00:00:00','200.00'),(5,7,5,'2002-03-03 00:00:00','300.00'),(6,4,4,'2002-03-03 00:00:00','100.00'),(7,5,5,'2002-03-03 00:00:00','50.00'),(8,8,2,'2002-03-03 00:00:00','50.00'),(9,2,2,'2002-03-03 00:00:00','2000.00'),(10,7,1,'2002-03-03 00:00:00','3000.00');
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gravadora`
--

DROP TABLE IF EXISTS `gravadora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gravadora` (
  `Cod_Grav` int(11) NOT NULL,
  `Nome_Grav` varchar(50) NOT NULL,
  PRIMARY KEY (`Cod_Grav`),
  UNIQUE KEY `UQ_Grav` (`Nome_Grav`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gravadora`
--

LOCK TABLES `gravadora` WRITE;
/*!40000 ALTER TABLE `gravadora` DISABLE KEYS */;
INSERT INTO `gravadora` VALUES (2,'EMI'),(1,'Polygram'),(3,'Som Livre'),(4,'Som Music');
/*!40000 ALTER TABLE `gravadora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionario` (
  `Cod_Func` int(11) NOT NULL,
  `Nome_Func` varchar(100) NOT NULL,
  `End_Func` varchar(200) NOT NULL,
  `Sal_Func` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Sexo_Func` char(1) NOT NULL DEFAULT 'F',
  PRIMARY KEY (`Cod_Func`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (1,'Vânia Gabriela Pereira','Rua A','2750.00','F'),(2,'Norberto Pereira da Silva','Rua B','300.00','M'),(3,'Olavo Linhares','Rua C','638.00','M'),(4,'Paula da Silva','Rua D','3300.00','F'),(5,'Rolando Rocha','Rua E','2000.00','M');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `titulo`
--

DROP TABLE IF EXISTS `titulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `titulo` (
  `Cod_Tit` int(11) NOT NULL,
  `Cod_Cat` int(11) NOT NULL,
  `Cod_Grav` int(11) NOT NULL,
  `Nome_CD` varchar(100) NOT NULL,
  `Val_CD` decimal(10,2) NOT NULL,
  `Qtd_Estq` int(11) NOT NULL,
  PRIMARY KEY (`Cod_Tit`),
  UNIQUE KEY `UQ_Tit` (`Nome_CD`),
  KEY `FK_Tit1` (`Cod_Cat`),
  KEY `FK_Tit2` (`Cod_Grav`),
  CONSTRAINT `FK_Tit1` FOREIGN KEY (`Cod_Cat`) REFERENCES `categoria` (`Cod_Cat`),
  CONSTRAINT `FK_Tit2` FOREIGN KEY (`Cod_Grav`) REFERENCES `gravadora` (`Cod_Grav`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titulo`
--

LOCK TABLES `titulo` WRITE;
/*!40000 ALTER TABLE `titulo` DISABLE KEYS */;
INSERT INTO `titulo` VALUES (1,1,1,'Tribalistas','30.00',1500),(2,1,2,'Tropicália','50.00',500),(3,1,1,'Aquele Abraço','50.00',600),(4,1,2,'Refazenda','60.00',1000),(5,1,3,'Totalmente Demais','50.00',2000),(6,1,3,'Travessia','55.00',500),(7,1,2,'Courage','30.00',200),(8,4,3,'Legião Urbana','30.00',100),(9,3,2,'The Beatles','30.00',300),(10,4,1,'Rita Lee','30.00',500);
/*!40000 ALTER TABLE `titulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado`
--

DROP TABLE IF EXISTS `estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estado` (
  `Sigla_Est` char(2) NOT NULL,
  `Nome_Est` char(50) NOT NULL,
  PRIMARY KEY (`Sigla_Est`),
  UNIQUE KEY `UQ_Est` (`Nome_Est`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado`
--

LOCK TABLES `estado` WRITE;
/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
INSERT INTO `estado` VALUES ('ES','Espirito Santo'),('MG','Minas Gerais'),('RJ','Rio de Janeiro'),('SP','São Paulo');
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `Cod_Cli` int(11) NOT NULL,
  `Cod_Cid` int(11) NOT NULL,
  `Nome_Cli` varchar(100) NOT NULL,
  `End_Cli` varchar(200) NOT NULL,
  `Renda_Cli` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Sexo_Cli` char(1) NOT NULL DEFAULT 'F',
  PRIMARY KEY (`Cod_Cli`),
  KEY `FK_Cli` (`Cod_Cid`),
  CONSTRAINT `FK_Cli` FOREIGN KEY (`Cod_Cid`) REFERENCES `cidade` (`Cod_Cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,1,'José Nogueira','Rua A','1500.00','F'),(2,1,'Angelo Pereira','Rua B','2000.00','M'),(3,1,'Além Mar Paranhos','Rua C','1500.00','F'),(4,1,'Catarina Souza','Rua D','892.00','F'),(5,1,'Vagner Costa','Rua E','950.00','F'),(6,2,'Antenor da Costa','Rua F','1582.00','M'),(7,2,'Maria Amélia de Souza','Rua G','1152.00','M'),(8,2,'Paulo Roberto Silva','Rua H','3250.00','M'),(9,3,'Fátima Souza','Rua I','1632.00','M'),(10,3,'Joel da Rocha','Rua J','2000.00','M');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conjuge`
--

DROP TABLE IF EXISTS `conjuge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conjuge` (
  `Cod_Cli` int(11) NOT NULL,
  `Nome_Conj` varchar(100) NOT NULL,
  `Renda_Conj` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Sexo_Conj` char(1) NOT NULL DEFAULT 'M',
  PRIMARY KEY (`Cod_Cli`),
  CONSTRAINT `FK_Conj` FOREIGN KEY (`Cod_Cli`) REFERENCES `cliente` (`Cod_Cli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conjuge`
--

LOCK TABLES `conjuge` WRITE;
/*!40000 ALTER TABLE `conjuge` DISABLE KEYS */;
INSERT INTO `conjuge` VALUES (1,'Carla Nogueira','2500.00','M'),(2,'Emilia Pereira','5500.00','F'),(6,'Altiva da Costa','3000.00','F'),(7,'Carlos de Souza','3250.00','M');
/*!40000 ALTER TABLE `conjuge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'db_cds'
--
/*!50003 DROP PROCEDURE IF EXISTS `muitolouca` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `muitolouca`(
banco varchar(100), tabela varchar(100))
begin
    select constraint_name as 'Constraint',
    table_schema as Banco,
    table_name as Tabela,
    Column_Name as 'Coluna Origem',
    referenced_table_name as
    'Tabela Referenciada',
    referenced_column_name as 
    'Coluna Referenciada'
    from information_schema.key_column_usage
    where table_schema= banco
    and table_name= tabela;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-07 14:51:24
CREATE DATABASE  IF NOT EXISTS `impacta` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `impacta`;
-- MySQL dump 10.13  Distrib 5.1.40, for Win32 (ia32)
--
-- Host: localhost    Database: impacta
-- ------------------------------------------------------
-- Server version	5.5.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consultores`
--

DROP TABLE IF EXISTS `consultores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consultores` (
  `cod_cons` int(11) DEFAULT NULL,
  `nome_cons` char(30) DEFAULT NULL,
  `end_cons` char(30) DEFAULT NULL,
  `fone_cons` char(20) DEFAULT NULL,
  `email_cons` char(20) DEFAULT NULL,
  `sal_cons` decimal(10,2) DEFAULT NULL,
  `data_cons` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultores`
--

LOCK TABLES `consultores` WRITE;
/*!40000 ALTER TABLE `consultores` DISABLE KEYS */;
INSERT INTO `consultores` VALUES (1,'Alexandre da Silva','Rua Direita, 25','3288-8799','alexandre@gratis.com','1200.00','2005-07-20'),(2,'Ana Claudia da Silva','Rua São Bento, 89','6524-7788','ana@gratis.com.br','920.00','2005-07-25'),(3,'Bruno da Silva','Rua 7 de Abril,100','8989-8887','bruno@gratis.com.br','1400.00','2005-08-01'),(4,'Débora da Silva','Avenida Paulista,1009','3123-1112','debora@gratis.com.br','900.00','2005-08-08'),(5,'Tatiana da Silva','Al Santos,12','5558-5777','tati@gratis.com.br','1800.00','2005-07-28'),(6,'Tatiana da Silva','Al. Jaú,38','8787-6676','tati@gratis.com.br','1200.00','2005-07-28'),(NULL,'Av. Paulista','Av. Paulista,200','2510-0000',NULL,NULL,NULL);
/*!40000 ALTER TABLE `consultores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cargo` (
  `cod_cargo` int(11) NOT NULL,
  `nome_cargo` varchar(50) NOT NULL,
  PRIMARY KEY (`cod_cargo`),
  UNIQUE KEY `uq_cargo` (`nome_cargo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (2,'Gerente'),(1,'Presidente'),(5,'Redator'),(4,'Revisor'),(3,'Supervisor');
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timao`
--

DROP TABLE IF EXISTS `timao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timao` (
  `codigo` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timao`
--

LOCK TABLES `timao` WRITE;
/*!40000 ALTER TABLE `timao` DISABLE KEYS */;
/*!40000 ALTER TABLE `timao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `part_tab`
--

DROP TABLE IF EXISTS `part_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `part_tab` (
  `c1` int(11) DEFAULT NULL,
  `c2` char(30) DEFAULT NULL,
  `c3` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1
/*!50100 PARTITION BY RANGE (year(c3))
(PARTITION p0 VALUES LESS THAN (1995) ENGINE = InnoDB,
 PARTITION p1 VALUES LESS THAN (1996) ENGINE = InnoDB,
 PARTITION p2 VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `part_tab`
--

LOCK TABLES `part_tab` WRITE;
/*!40000 ALTER TABLE `part_tab` DISABLE KEYS */;
INSERT INTO `part_tab` VALUES (1,'testing partitions','1995-01-01'),(1,'testing partitions','1996-01-01'),(1,'testing partitions','2000-01-01');
/*!40000 ALTER TABLE `part_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treinamento`
--

DROP TABLE IF EXISTS `treinamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treinamento` (
  `cod_trein` int(11) DEFAULT NULL,
  `nome_trein` varchar(15) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treinamento`
--

LOCK TABLES `treinamento` WRITE;
/*!40000 ALTER TABLE `treinamento` DISABLE KEYS */;
INSERT INTO `treinamento` VALUES (1,'Excel','720.00'),(2,'Word','480.00'),(3,'PPT','480.00');
/*!40000 ALTER TABLE `treinamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empregados`
--

DROP TABLE IF EXISTS `empregados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empregados` (
  `cod_emp` int(11) DEFAULT NULL,
  `nome_emp` varchar(30) DEFAULT NULL,
  `data_emp` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empregados`
--

LOCK TABLES `empregados` WRITE;
/*!40000 ALTER TABLE `empregados` DISABLE KEYS */;
INSERT INTO `empregados` VALUES (10,'Jailton Pires','1985-03-09'),(11,'Matheus dos Santos','1998-04-07'),(12,'Zumira Albuquerque','2000-10-12'),(1,'Alexandre da Silva','2005-07-20'),(2,'Ana Claudia da Silva','2005-07-25'),(3,'Bruno da Silva','2005-08-01'),(4,'Débora da Silva','2005-08-08'),(5,'Tatiana da Silva','2005-07-28'),(6,'Tatiana da Silva','2005-07-28'),(NULL,'Av. Paulista',NULL),(10,'Jailton Pires','1985-03-09'),(11,'Matheus dos Santos','1998-04-07'),(12,'Zumira Albuquerque','2000-10-12'),(10,'Jailton Pires','1985-03-09'),(11,'Matheus dos Santos','1998-04-07'),(12,'Zumira Albuquerque','2000-10-12');
/*!40000 ALTER TABLE `empregados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionario` (
  `cod_func` int(11) NOT NULL,
  `cod_cargo` int(11) NOT NULL,
  `nome_func` varchar(50) NOT NULL,
  `salario_func` decimal(10,2) NOT NULL,
  `rg_func` varchar(15) NOT NULL,
  PRIMARY KEY (`cod_func`),
  UNIQUE KEY `uq_func` (`rg_func`),
  KEY `fk_func` (`cod_cargo`),
  CONSTRAINT `fk_func` FOREIGN KEY (`cod_cargo`) REFERENCES `cargo` (`cod_cargo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (1,5,'Luís Pereira','3000.00','27.291.905'),(2,5,'Antonio Almeida','3000.00','15.970.247'),(3,3,'Donizete Ribeiro','2800.00','27.151.908'),(4,3,'Gabriela Moura','4700.00','25.279.145'),(5,2,'Emílio Duarte','5000.00','17.278.246'),(6,1,'Carolina Ferreira','9000.00','18.154.578');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionarios` (
  `cod_func` int(11) DEFAULT NULL,
  `nome_func` char(30) DEFAULT NULL,
  `end_func` char(30) DEFAULT NULL,
  `fone_func` char(20) DEFAULT NULL,
  `email_func` char(20) DEFAULT NULL,
  `sal_func` decimal(10,2) DEFAULT NULL,
  `data_func` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionarios`
--

LOCK TABLES `funcionarios` WRITE;
/*!40000 ALTER TABLE `funcionarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `funcionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `cod_cli` int(11) DEFAULT NULL,
  `nome_cli` varchar(30) DEFAULT NULL,
  `end_cli` varchar(30) DEFAULT NULL,
  `fone_cli` varchar(10) DEFAULT NULL,
  `email_cli` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Alexandre da Silva','Rua Direita, 25','3288-8799','ale@gratis.com.br'),(2,'Ana Cláudia da Silva','Rua São Bento,89','6524-7788','ana@gratis.com.br'),(3,'Bruno da Silva','Rua 7 de Abril, 100','3288-8799','bruno@gratis.com.br'),(4,'Débora da Silva','Rua 7 de Abril, 100','3288-8799','debora@gratis.com.br'),(5,'Tatiana da Silva','Rua 7 de Abril, 100','3288-8799','tati@gratis.com.br'),(6,'Tatiana da Silva','Al. Jaú, 38','8787-6676','tati@gratis.com.br');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `part_tab2`
--

DROP TABLE IF EXISTS `part_tab2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `part_tab2` (
  `c1` int(11) DEFAULT NULL,
  `c2` char(30) DEFAULT NULL,
  `c3` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1
/*!50100 PARTITION BY RANGE (year(c3))
(PARTITION p0 VALUES LESS THAN (1995) ENGINE = MyISAM,
 PARTITION p1 VALUES LESS THAN (1996) ENGINE = MyISAM,
 PARTITION p2 VALUES LESS THAN MAXVALUE ENGINE = MyISAM) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `part_tab2`
--

LOCK TABLES `part_tab2` WRITE;
/*!40000 ALTER TABLE `part_tab2` DISABLE KEYS */;
INSERT INTO `part_tab2` VALUES (1,'testing partitions','1995-01-01'),(1,'testing partitions','1996-01-01'),(1,'testing partitions','2000-01-01');
/*!40000 ALTER TABLE `part_tab2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teste`
--

DROP TABLE IF EXISTS `teste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teste` (
  `cod_teste` int(11) NOT NULL AUTO_INCREMENT,
  `nome_teste` varchar(50) DEFAULT NULL,
  `email_teste` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cod_teste`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teste`
--

LOCK TABLES `teste` WRITE;
/*!40000 ALTER TABLE `teste` DISABLE KEYS */;
/*!40000 ALTER TABLE `teste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produtos` (
  `cod_prod` int(11) DEFAULT NULL,
  `nome_prod` varchar(40) DEFAULT NULL,
  `tipo_prod` varchar(20) DEFAULT NULL,
  `qtd_prod` int(11) DEFAULT NULL,
  `val_prod` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'Impressora','Informática',250,'798.60'),(2,'Câmera Digital','Digitais',350,'600.00'),(3,'DVD Player','Eletrônicos',300,'660.00'),(4,'Monitor','Informática',400,'1089.00'),(5,'Televisor','Eletrônicos',350,'660.00'),(6,'Filmadora Digital','Digitais',500,'600.00'),(7,'Celular','Telefone',450,'935.00'),(8,'Teclado','Informática',350,'544.50'),(9,'Vídeocassete','Eletrônicos',250,'330.00'),(10,'Mouse','Informática',400,'72.60');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `nome_usu` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `cod_cli` int(11) DEFAULT NULL,
  `nome_cli` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Alexandre da Silva'),(2,'Ana Cláudia da Silva'),(3,'Bruno da Silva'),(4,'Débora da Silva'),(5,'Tatiana da Silva');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t`
--

DROP TABLE IF EXISTS `t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t` (
  `ti` int(11) NOT NULL,
  PRIMARY KEY (`ti`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t`
--

LOCK TABLES `t` WRITE;
/*!40000 ALTER TABLE `t` DISABLE KEYS */;
/*!40000 ALTER TABLE `t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'impacta'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-07 14:51:25
