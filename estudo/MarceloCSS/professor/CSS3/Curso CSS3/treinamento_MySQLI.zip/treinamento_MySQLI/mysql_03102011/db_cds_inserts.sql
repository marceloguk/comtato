-- Exercicio Cap_7

-- Lab_1

use DB_CDS;

-- Inserts

-- -----------------------------------------------------
insert into artista values
(1,'Marisa Monte'),
(2,'Gilberto Gil'),
(3,'Caetano Veloso'),
(4,'Milton Nascimento'),
(5,'Legi�o Urbana'),
(6,'The Beatles'),
(7,'Rita Lee');
-- -----------------------------------------------------
insert into gravadora values
(1,'Polygram'),
(2,'EMI'),
(3,'Som Livre'),
(4,'Som Music');
-- -----------------------------------------------------
insert into categoria values
(1,'MPB'),(2,'Trilha Sonora'),
(3,'Rock Internacional'),(4,'Rock Nacional');
-- -----------------------------------------------------
insert into estado values
('SP','S�o Paulo'),('MG','Minas Gerais'),
('RJ','Rio de Janeiro'),('ES','Espirito Santo');
-- -----------------------------------------------------
insert into cidade values
(1,'SP','S�o Paulo'),
(2,'SP','Sorocaba'),
(3,'SP','Jundia�'),
(4,'SP','Americana'),
(5,'SP','Araraquara'),
(6,'MG','Ouro Preto'),
(7,'ES','Cachoeiro de Itapemirim');
-- -----------------------------------------------------
insert into Cliente values (1,1,'Jos� Nogueira','Rua A',1500.00,'F')
,(2,1,'Angelo Pereira','Rua B',2000.00,'M')
,(3,1,'Al�m Mar Paranhos','Rua C',1500.00,'F')
,(4,1,'Catarina Souza','Rua D',892.00,'F')
,(5,1,'Vagner Costa','Rua E',950.00,'F')
,(6,2,'Antenor da Costa','Rua F',1582.00,'M')
,(7,2,'Maria Am�lia de Souza','Rua G',1152.00,'M')
,(8,2,'Paulo Roberto Silva','Rua H',3250.00,'M')
,(9,3,'F�tima Souza','Rua I',1632.00,'M')
,(10,3,'Joel da Rocha','Rua J',2000.00,'M');
-- -----------------------------------------------------
insert into Conjuge values
 (1,'Carla Nogueira',2500.00,'M'),
(2,'Emilia Pereira',5500.00,'F'),
(6,'Altiva da Costa',3000.00,'F'),
(7,'Carlos de Souza',3250.00,'M');
-- -----------------------------------------------------
insert into Funcionario values (1,'V�nia Gabriela Pereira','Rua A',2500.00,'F'),
(2,'Norberto Pereira da Silva','Rua B',300.00,'M'),
(3,'Olavo Linhares','Rua C',580.00,'M'),
(4,'Paula da Silva','Rua D',3000.00,'F'),
(5,'Rolando Rocha','Rua E',2000.00,'M');
-- -----------------------------------------------------
insert into Dependente values
(1,1,'Ana Pereira','F'),
(2,1,'Roberto Pereira','M'),
(3,1,'Celso Pereira','M'),
(4,3,'Brisa Linhares','F'),
(5,3,'Mari Sol Linhares','F'),
(6,4,'Sonia da Silva','F');
-- -----------------------------------------------------
insert into Titulo values (1,1,1,'Tribalistas',30.00,1500),
(2,1,2,'Tropic�lia',50.00,500),
(3,1,1,'Aquele Abra�o',50.00,600),
(4,1,2,'Refazenda',60.00,1000),
(5,1,3,'Totalmente Demais',50.00,2000),
(6,1,3,'Travessia',55.00,500),
(7,1,2,'Courage',30.00,200),
(8,4,3,'Legi�o Urbana',30.00,100),
(9,3,2,'The Beatles',30.00,300),
(10,4,1,'Rita Lee',30.00,500);
-- -----------------------------------------------------
insert into Pedido values (1,1,2,'02/05/02',1500.00),
(2,3,4,'02/05/02',50.00),
(3,4,5,'02/06/02',100.00),
(4,1,4,'02/02/03',200.00),
(5,7,5,'02/03/03',300.00),
(6,4,4,'02/03/03',100.00),
(7,5,5,'02/03/03',50.00),
(8,8,2,'02/03/03',50.00),
(9,2,2,'02/03/03',2000.00),
(10,7,1,'02/03/03',3000.00);
-- -----------------------------------------------------
insert into Titulo_Artista values (1,1),
(2,2),(3,2),(4,2),(5,3),(6,4),(7,4),(8,5),(9,6),(10,7);
-- -----------------------------------------------------
insert into Titulo_Pedido values (1,1,2,30.00),
(1,2,3,20.00),
(2,1,1,50.00),
(2,2,3,30.00),
(3,1,2,40.00),
(4,2,3,20.00),
(5,1,2,25.00),
(6,2,3,30.00),
(6,3,1,35.00),
(7,4,2,55.00),
(8,1,4,60.00),
(9,2,3,15.00),
(10,7,2,15.00);

-- ------------------------------------------------------------------------------
-- Selects

select 'Tim�o Campe�o';