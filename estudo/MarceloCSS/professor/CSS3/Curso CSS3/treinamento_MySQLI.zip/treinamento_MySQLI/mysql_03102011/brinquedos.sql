use labs;
create table brinquedo
(
	cod_brinq int,
	nome_brinq varchar(50),,
	idade_brinq tinyint,
	qtd_brinq int,
	val_brinq decimal(10,2)
);


insert into brinquedo values
(1,'Amiguinha',7,100,150.00),
(2,'Beb� Balancinho',3,200,30.00),
(3,'Beb� Chuveirinho',3,50,25.00),
(4,'Bolinha de Sab�o',5,40,30.00),
(5,'Em�lia',2,70,60.00),
(6,'Hora do Pap�',1,50,50.00),
(7,'Frutinha Chaveirinho',2,30,20.00),
(8,'Banco Imobili�rio',10,10,100.00),
(9,'Cai n�o Cai',3,15,35.00),
(10,'Cara a Cara',4,16,28.00),
(11,'Cilada',10,17,25.00),
(12,'Combate',7,19,40.00),
(13,'Detetive',7,20,50.00),
(14,'A Galinha Magricela',7,21,90),
(15,'Puxa Puxa Batatinha',2,22,150.00),
(16,'Rob� Baby',2,23,200.00),
(17,'Action Man',3,23,200.00),
(18,'Batcicle',5,30,180.00),
(19,'Batman',3,40,50.00),
(20,'Superman',4,50,50.00),
(21,'Maga Patal�gica',4,66,100.00),
(22,'Paty Gatinha',3,80,20.00),
(23,'Goleiro Maluco',5,92,20.00),
(24,'Bichinho do Beb�',6,100,20.00),
(25,'Caixa-Encaixa',7,200,35.00),
(26,'Guitarrinha do Beb�',4,200,80.00),
(27,'Sr. e Sra. Cabe�a de Batata',6,300,150.00),
(28,'Ponteirinho',4,100,50.00),
(29,'Batecar',5,200,30.00),
(30,'Capotcar',5,200,30);






