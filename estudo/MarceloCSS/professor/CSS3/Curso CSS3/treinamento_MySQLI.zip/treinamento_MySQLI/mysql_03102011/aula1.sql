show databases;

use mysql;

create database impacta;

use impacta;

create table cliente
(
    cod_cli      int,
    nome_cli     varchar(30)
);

insert into cliente
values
(1,'Alexandre da Silva'),
(2,'Ana Cláudia da Silva'),
(3,'Bruno da Silva'),
(4,'Débora da Silva'),
(5,'Tatiana da Silva');

select * from clientes;
where cod_cli = 2;

explain cliente;
describe cliente;
desc cliente;


show storage engines;

create table timao
(
    codigo int
)engine = MyISAM;


select * from timao;
select * from cliente;

use impacta;

show tables;

select table_name, engine
from information_schema.tables
where table_name='timao';

use information_schema;

select * from table




create table professor
(
    cod_prof int,
    nome_prof   char(30),
    sexo_prof   char(1),
    sal_prof    dec(10,2),
    datacad_prof datetime
);

use impacta;
show tables;
select database();



