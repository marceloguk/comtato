use db_cds;
-- ------------------------------
select cod_cli,
count(cod_cli) as qtd_ped
from pedido
group by cod_cli;
-- ------------------------------
select cliente.nome_cli,
count(pedido.cod_cli) as qtd_ped
from pedido inner join cliente
using(cod_cli) -- mysql
group by cliente.nome_cli;
-- ------------------------------
select * from titulo;
-- ------------------------------
select cod_cat,
count(cod_cat) as total
from titulo
group by cod_cat;
-- ------------------------------
select cod_grav,
count(cod_grav) as total
from titulo
group by cod_grav;
-- ------------------------------
-- pedido
-- cod_func | total
select cod_func,
count(cod_func) as total
from pedido
group by cod_func;
-- ------------------------------
-- dependente
-- cod_func | total_dep
-- ------------------------------
select cod_func,
count(*) as total
from dependente
group by cod_func;