﻿/*Desafios Timão*/
/*
1º - Você é o DBA da Empresa DB Cds Incorporation, o departamento financeiro precisa
emitir um relatório para a auditoria do Controller, sobre os clientes que moram na 
cidade de São Paulo, que compraram cds de MPB de uma funcionária chamada Paula da Silva,
exiba: O nome do cliente, tudo da tabela pedido, o nome do funcionário,
o nome do cd comprado bem como sua categoria e gravadora.

2º - A empresa de pagamentos online Pay Pal, está selecionando para seu quadro, funcionários
que possuam boas experiências de vendas para clientes casados, portanto solicitou que você
crie uma consulta para exibir quem são os funcionários da empresa Parceira DB Cds Incorporation
que venderam cds de MPB para clientes casados no período de março de 2002, que moram na cidade
de são paulo e compraram e que além de ser MPB seja do artista Gilberto Gil.
*/



