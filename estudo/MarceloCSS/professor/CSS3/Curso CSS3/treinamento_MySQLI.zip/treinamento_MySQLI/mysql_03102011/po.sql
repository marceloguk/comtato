use impacta;

create table teste
(
    cod_teste int auto_increment,
    nome_teste varchar(50),
    email_teste varchar(100),
    constraint pk_teste primary key(cod_teste)
)
data directory = 'c:\timao'
index directory = 'c:\timao\index';
select * from teste limit 0,10;
select found_rows();

create index iteste on teste(cod_teste);

drop table teste;


CREATE TABLE part_tab2 
( c1 int default NULL, 
c2 char (30) default NULL, 
c3 date default NULL 
) engine=MyISAM 
PARTITION BY RANGE (year(c3)) ( 
PARTITION p0 VALUES LESS THAN (1995) DATA DIRECTORY 'c:/timao/p0', 
PARTITION p1 VALUES LESS THAN (1996) DATA DIRECTORY 'c:/timao/p1', 
PARTITION p2 VALUES LESS THAN MAXVALUE DATA DIRECTORY 'c:/timao/p2'); 
insert into part_tab2
values (1,'testing partitions','1995-01-01'); 
insert into part_tab2 
values (1,'testing partitions','1996-01-01'); 
insert into part_tab2 
values (1,'testing partitions','2000-01-01'); 


EXPLAIN partitions SELECT c3 
FROM part_tab 
WHERE c3 < '1996-01-01' ;


