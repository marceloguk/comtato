use impacta;

create table produtos
(
    cod_prod int,
    nome_prod varchar(40),
    tipo_prod   varchar(20),
    qtd_prod    int,
    val_prod    dec(10,2)
);

insert into produtos values
(1,'Impressora','Informática',200,600.00),
(2,'Câmera Digital','Digitais',300,600.00),
(3,'DVD Player','Eletrônicos',250,600.00),
(4,'Monitor','Informática',400,900.00),
(5,'Televisor','Eletrônicos',350,600.00),
(6,'Filmadora Digital','Digitais',500,600.00),
(7,'Celular','Telefone',450,850.00),
(8,'Teclado','Informática',300,450.00),
(9,'Vídeocassete','Eletrônicos',200,300.00),
(10,'Mouse','Informática',400,60.00);
-- -------------------------------
select * from produtos 
where qtd_prod > 200
order by qtd_prod
limit 3;
-- -------------------------------
update produtos
set val_prod = val_prod * 1.1
where tipo_prod = 'Informática';
-- -------------------------------
-- collation
-- latin1_general_ci_ai
-- case insensitive (a == A)
-- case sensitive(a != A)
-- accent insensitive(Jose, José)
-- -------------------------------
select * from produtos
where tipo_prod ='Informática';
-- -------------------------------
use information_schema;
-- -------------------------------
show tables;
select * from schemata;
-- -------------------------------
explain schemata;
-- -------------------------------
use impacta;
-- -------------------------------
update produtos
set qtd_prod = qtd_prod + 50
where qtd_prod <= 300;
-- -------------------------------
update produtos
set val_prod = val_prod * 1.1
where tipo_prod = 'Informática'
and val_prod <= 700;
-- -------------------------------
update produtos
set val_prod = val_prod * 1.1
where tipo_prod = 'Eletrônicos'
or val_prod >= 700;
-- -------------------------------
select * from produtos
where tipo_prod = 'Eletrônicos' or
tipo_prod = 'Informática' or
tipo_prod ='digitais';
-- -------------------------------
select * from produtos
where tipo_prod 
in('Eletrônicos','Informática','Digitais');
-- -------------------------------
select * from produtos
where tipo_prod 
not in('Eletrônicos','Informática','Digitais');
-- -------------------------------
select * from produtos
where tipo_prod != 'Eletrônicos' and
tipo_prod <> 'Informática' and
tipo_prod <> 'Digitais';
-- -------------------------------
select * from produtos
where val_prod >= 300 and val_prod <= 500;
-- -------------------------------
select * from produtos 
where val_prod between 300 and 500;
-- key range
-- -------------------------------
-- alta seletividade x baixa densidade -ok
-- baixa seletividade x alta densidade - x
-- -------------------------------
select * from produtos 
where val_prod not between 300 and 500;
-- -------------------------------
-- like - como isto
-- ' - início e término de expressão
-- % - qualquer caracter ou nenhum
-- _ - exatamente uma posição
-- /***SQL SERVER Jo[sz]é **/
-- ----------------------------------
select * from produtos
where nome_prod like 'T%';
-- ----------------------------------
select * from produtos
where nome_prod like '%r';
-- ----------------------------------
select * from produtos
where tipo_prod like '%n%';
-- ----------------------------------
select * from produtos
where nome_prod like '%e_';
-- ----------------------------------
select * from produtos
where nome_prod not like 'a%' and 
nome_prod not like 'e%' and
nome_prod not like 'i%' and
nome_prod not like 'o%' and
nome_prod not like 'u%';
-- ----------------------------------
select * from produtos
where nome_prod not like '[aeiou]%';
-- ----------------------------------
create table usuarios
(
    nome_usu varchar(50)
);
-- ----------------------------------
insert into usuarios values
('José'),('Jozé'),('Jose'),('Joze'),
('Jósé'),('Milton'),('Milton'),('Miuton'),
('Miutom'),('Jonn'),('Jon'),('Jhon'),
('Jhonn'),('Jom'),('Jhom');
-- ----------------------------------
select * from usuarios
where nome_usu = 'Jon';
-- ----------------------------------
select * from usuarios
where soundex(nome_usu) = soundex('Jon');
-- ----------------------------------
select 'Timão campeão do Brasileirão' as
título;
-- ----------------------------------
select soundex('jon');