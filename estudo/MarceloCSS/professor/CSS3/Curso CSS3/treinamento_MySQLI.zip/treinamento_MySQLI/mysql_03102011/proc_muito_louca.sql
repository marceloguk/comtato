
use db_cds;
delimiter $$
create procedure muitolouca(
banco varchar(100), tabela varchar(100))
begin
    select constraint_name as 'Constraint',
    table_schema as Banco,
    table_name as Tabela,
    Column_Name as 'Coluna Origem',
    referenced_table_name as
    'Tabela Referenciada',
    referenced_column_name as 
    'Coluna Referenciada'
    from information_schema.key_column_usage
    where table_schema= banco
    and table_name= tabela;
end
$$

delimiter ;
-- -------------------------------------
call muitolouca('db_cds','titulo');
-- -------------------------------------