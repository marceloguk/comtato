use db_cds;
/*
Cross Join - Cruza dados de duas ou
mais tabelas, é usado para pelo menos
três situações.

 - Teste de Stress
 - Teste de Possibilidades
 - Geo Processamento
*/
-- -------------------------------
select nome_cd, nome_cli  from 
cliente cross join titulo;
-- -------------------------------
update funcionario inner join dependente
on funcionario.cod_func = dependente.cod_func
set sal_func = sal_func * 1.1;
-- -------------------------------
delete pedido
from funcionario inner join pedido
on funcionario.cod_func = pedido.cod_func
where funcionario.cod_func = 50;
-- where pedido.cod_func is null;
-- -------------------------------
-- union all permite unir duas ou mais 
-- consultas em uma única tela de 
-- resultados

select cod_cli as cod_pes,
'Cliente' as tipo_pes,
nome_cli as nome_pes,
sexo_cli as sexo_pes,
renda_cli as sal_pes
from cliente

union all

select cod_func as funcionario,
'Funcionario',nome_func, 'ND',sal_func
from funcionario
order by nome_pes;


use impacta;

select * from cargo
where cod_cargo not in
(select cod_cargo from funcionario);

use db_cds;

select * from cliente
where cod_cli not in
(select cod_cli from conjuge);

select * from cliente
where cod_cli in
(select cod_cli from conjuge);

select * from funcionario
where cod_func in
(select cod_func from dependente);

select * from funcionario
where cod_func not in
(select cod_func from dependente);
-- ----------------------------------
select * from cliente
where renda_cli =
(select max(renda_cli) from cliente);
-- ----------------------------------
select * from cliente
where renda_cli =
(select min(renda_cli) from cliente);
-- ----------------------------------
select *,
(
select count(cod_func) from dependente
where cod_func = funcionario.cod_func
) as qtd
from funcionario;
-- ----------------------------------
update funcionario
set sal_func = sal_func * 1.1
where cod_func in
(select cod_func from dependente);
-- ----------------------------------
delete from funcionario
where cod_func not in
(select cod_func from dependente);
-- ----------------------------------
select * from categoria
where cod_cat not in
(select cod_cat from titulo);
-- ----------------------------------
select * from gravadora
where cod_grav not in
(select cod_grav from titulo);
-- ----------------------------------
select * from funcionario
where cod_func in
(select cod_func from dependente)
and cod_func not in
(select cod_func from pedido);
-- ----------------------------------
-- funcionario - pedido - conjuge
-- ----------------------------------
select * from funcionario
where cod_func in (select cod_func
from pedido where cod_cli in(
select cod_cli from conjuge));
-- ----------------------------------
select * from titulo
where val_cd = 
(select max(val_cd) from titulo);
-- ----------------------------------
select * from cliente where renda_cli=
(select distinct renda_cli from cliente
order by renda_cli desc limit 2,1);
-- ----------------------------------
select tipo_roupa,
sum(qtd_roupa) as total
from roupa
group by tipo_roupa;
-- ----------------------------------
select marca_roupa,
sum(qtd_roupa) as total,
sum(val_roupa) as total_pago
from roupa
group by marca_roupa;
