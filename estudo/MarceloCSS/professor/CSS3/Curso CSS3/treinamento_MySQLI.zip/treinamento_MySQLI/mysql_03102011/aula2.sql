use impacta;
-- isto é um comentário de linha
/*
isto é um comentário
de
bloco
*/
/***
@Autor: Glaucio Daniel
@Data: 2011-10-04
@Objetivo: Criação de Tabelas e 
cadastro de dados
*/
create table clientes
(
    cod_cli int,
    nome_cli varchar(30),
    end_cli varchar(30),
    fone_cli    varchar(10),
    email_cli varchar(60)
);
-- --------------------------------
insert into clientes values
(1,'Alexandre da Silva','Rua Direita, 25',
'3288-8799','ale@gratis.com.br'),
(2,'Ana Cláudia da Silva','Rua São Bento,89',
'6524-7788','ana@gratis.com.br'),
(3,'Bruno da Silva','Rua 7 de Abril, 100',
'3288-8799','bruno@gratis.com.br'),
(4,'Débora da Silva','Rua 7 de Abril, 100',
'3288-8799','debora@gratis.com.br'),
(5,'Tatiana da Silva','Rua 7 de Abril, 100',
'3288-8799','tati@gratis.com.br');
-- ------------------------------
select * from clientes;
-- ------------------------------
/*
A Linguagem SQL é divida em pelo menos
três grupos

DCL - Data Control Language
    grant, deny, revoke
DDL - Data Definition Language
    create, alter, drop
DML - Data Manipulation Language
    insert,update, delete,select
    
Query - Select
-- where - JC - Justa Causa
*/
-- ------------------------------
select * from clientes;
-- ------------------------------
select nome_cli, fone_cli, email_cli
from clientes;
-- ------------------------------
-- Alias - apelido
select nome_cli as Nome_Cliente,
fone_cli as Telefone_Cliente,
email_cli Email_Cliente
from clientes;
-- ------------------------------
select nome_cli as "Nome do Cliente",
fone_cli as "Telefone do Cliente",
email_cli as "E-mail do Cliente"
from clientes;
-- ------------------------------
select * from clientes;
-- ------------------------------
select nome_cli as Nome,
fone_cli as Telefone,
email_cli as Email,
'Pessoa Física' as Tipo
from clientes;
-- ------------------------------
create table treinamento
(
    cod_trein int,
    nome_trein  varchar(15),
    valor       dec(10,2)
);
-- ------------------------------
insert into treinamento values
(1,'Excel',720),(2,'Word',480),
(3,'PPT',480);
-- ------------------------------
select * from treinamento;
-- ------------------------------
select nome_trein as Treinamento,
valor,
cast(valor * 0.9 as dec(10,2)) as 'Valor com desconto'
from treinamento;

select nome_trein as Treinamento,
valor,
convert(valor * 0.9, dec(10,2)) as 'Valor com desconto'
from treinamento;
-- ------------------------------
-- pentaho.com
-- www.amcharts.com
-- ------------------------------
insert into clientes values
(6,'Tatiana da Silva','Al. Jaú, 38',
'8787-6676','tati@gratis.com.br');
-- ------------------------------
select * from clientes;
-- ------------------------------
select nome_cli from clientes;
-- ------------------------------
select distinct nome_cli from clientes;
-- ------------------------------
select distinct cod_cli,nome_cli
from clientes;
-- ------------------------------
select * from clientes limit 3,2;
-- ------------------------------
select * from clientes limit 3;
-- ------------------------------
/*
comandos - podem ser escritos sozinhos

cláusulas - dependem de comandos

operadores - dependem de cláusulas
*/
-- select insert update delete create
-- where, order by, limit, distinct, 
-- > < = <> and or + - * / asc desc
-- -----------------------------------
create table funcionarios
(
    cod_func int,
    nome_func char(30),
    end_func    char(30),
    fone_func   char(20),
    email_func  char(20),
    sal_func    dec(10,2),
    data_func   date
);
-- ----------------------------------
insert into funcionarios values
(1,'Alexandre da Silva','Rua Direita, 25','3288-8799','alexandre@gratis.com',1200.00,'2005-07-20'),
(2,'Ana Claudia da Silva','Rua São Bento, 89','6524-7788','ana@gratis.com.br',920.00,'2005-07-25'),
(3,'Bruno da Silva','Rua 7 de Abril,100','8989-8887','bruno@gratis.com.br',1400.00,'2005-08-01'),
(4,'Débora da Silva','Avenida Paulista,1009','3123-1112','debora@gratis.com.br',900.00,'2005-08-08'),
(5,'Tatiana da Silva','Al Santos,12','5558-5777','tati@gratis.com.br',1800.00,'2005-07-28'),
(6,'Tatiana da Silva','Al. Jaú,38','8787-6676','tati@gratis.com.br',1200.00,'2005-07-28');

select * from funcionarios;

insert into funcionarios(end_func,
nome_func, fone_func)values
('Av. Paulista,200','Av. Paulista','2510-0000');

explain funcionarios;
describe funcionarios;
desc funcionarios;
-- sp_help
-- SQLite
create table consultores
(
    cod_cons int,
    nome_cons char(30),
    end_cons    char(30),
    fone_cons   char(20),
    email_cons  char(20),
    sal_cons    dec(10,2),
    data_cons   date
);
-- ---------------------------------
insert into consultores
select * from funcionarios;
-- ---------------------------------
create table empregados
(
cod_emp int,
nome_emp varchar(30),
data_emp date
);
-- ---------------------------------
insert into empregados values
(10,'Jailton Pires','1985-03-09'),
(11,'Matheus dos Santos','1998-04-07'),
(12,'Zumira Albuquerque','2000-10-12');
-- ---------------------------------
desc funcionarios;
-- ---------------------------------
insert into funcionarios

select cod_emp, nome_emp,
'Não tem endereço','0000-0000',
'nao@tem.email',0, data_emp
from empregados;
-- ---------------------------------
insert into funcionarios
(cod_func, nome_func, data_func)
select * from empregados;
-- ---------------------------------
select * from funcionarios;
-- ---------------------------------
insert into empregados
select cod_func, nome_func, data_func
from funcionarios;
-- ---------------------------------
select * from funcionarios;
-- ---------------------------------
update funcionarios
set sal_func = sal_func * 1.1;
-- ---------------------------------
delete from funcionarios;
-- ---------------------------------