-- Exercicio Cap_7

-- Lab_1

-- Criar Tabelas

create database DB_CDS;

use DB_CDS;

-- ------------------------------------------------------------------------------
-- 1
create table Artista
(
Cod_Art		int not null,
Nome_Art	varchar(100) not null,
Constraint PK_Art primary key (Cod_Art),
Constraint UQ_Art unique (Nome_Art)
);



-- ----------------------------------------------------------------------------
-- 2

create table Gravadora
(
Cod_Grav		int not null,
Nome_Grav	varchar(50) not null,
Constraint PK_Grav primary key (Cod_Grav),
Constraint UQ_Grav unique (Nome_Grav)
);



-- -----------------------------------------------------------------------------
-- 3

create table Categoria
(
Cod_Cat		int not null,
Nome_Cat	varchar(50) not null,
Constraint PK_Cat primary key (Cod_Cat),
Constraint UQ_Cat unique (Nome_Cat)
);


-- -----------------------------------------------------------------------------
-- 4

create table Estado
(
Sigla_Est	char(2) not null,
Nome_Est	char(50) not null,
Constraint PK_Est primary key (Sigla_Est),
Constraint UQ_Est unique (Nome_Est)
);


-- -----------------------------------------------------------------------------
-- 5

create table Cidade
(
Cod_Cid		int not null,
Sigla_Est	char(2) not null,
Nome_Cid	varchar(100) not null,
Constraint PK_Cid primary key (Cod_Cid),
Constraint FK_Cid foreign key (Sigla_Est) references Estado (Sigla_Est)
);



-- -----------------------------------------------------------------------------
-- 6
create table Cliente
(
Cod_Cli		int not null,
Cod_Cid		int not null,
Nome_Cli	varchar(100) not null,
End_Cli		varchar(200) not null,
Renda_Cli	decimal(10,2) not null default 0,
Sexo_Cli	char(1) not null default 'F',
Constraint PK_Cli primary key (Cod_Cli),
Constraint FK_Cli foreign key (Cod_Cid) references Cidade (Cod_Cid),
Constraint CH_Cli1 check (Renda_Cli >=0),
Constraint CH_Cli2 check (Sexo_Cli in ('F','M'))
);



-- -------------------------------------------------------------------------------
-- 7

create table Conjuge
(
Cod_Cli		int not null,
Nome_Conj	varchar(100) not null,
Renda_Conj	decimal(10,2) not null default 0,
Sexo_Conj char(1) not null default 'M',
Constraint PK_Conj primary key(Cod_Cli),
Constraint FK_Conj foreign key(Cod_Cli) references Cliente (Cod_Cli),
Constraint CH_Conj1 check (Renda_Conj >= 0),
Constraint CH_Conj2 check (Sexo_Conj in ('F','M'))
);



-- ------------------------------------------------------------------------------
-- 8

create table Funcionario
(
Cod_Func	int not null,
Nome_Func	varchar(100) not null,
End_Func	varchar(200) not null,
Sal_Func	decimal(10,2) not null default 0,
Sexo_Func	char(1) not null default 'F',
Constraint PK_Func primary key (Cod_Func),
Constraint CH_Func1 check (Sal_Func >= 0),
Constraint CH_Func2 check (Sexo_Func in ('F','M'))
);



-- -----------------------------------------------------------------------------
-- 9

create table Dependente
(
Cod_Dep	int not null,
Cod_Func int not null,
Nome_Dep varchar(100) not null,
Sexo_Dep char(1) not null default 'M',
Constraint PK_Dep primary key(Cod_Dep),
Constraint FK_Dep foreign key(Cod_Func) references Funcionario (Cod_Func),
Constraint CH_Dep1 check (Sexo_Dep in ('F','M'))
);



-- --------------------------------------------------------------------------
-- 10

create table Titulo
(
Cod_Tit int not null,
Cod_Cat int not null,
Cod_Grav int not null,
Nome_CD varchar(100) not null,
Val_CD decimal(10,2) not null,
Qtd_Estq int not null,
Constraint PK_Tit primary key(Cod_Tit),
Constraint FK_Tit1 foreign key(Cod_Cat) references Categoria(Cod_Cat),
Constraint FK_Tit2 foreign key(Cod_Grav) references Gravadora(Cod_Grav),
Constraint UQ_Tit unique (Nome_CD),
Constraint CH_Tit1 check (Val_CD >0),
Constraint CH_Tit2 check (Qtd_Estq >=0)
);



-- ----------------------------------------------------------------------------
-- 11

create table Pedido
(
Num_Ped int not null,
Cod_Cli int not null,
Cod_Func int not null,
Data_Ped datetime not null,
val_Ped decimal(10,2) not null default 0,
Constraint PK_Ped primary key(Num_Ped),
Constraint FK_Ped1 foreign key(Cod_Cli) references Cliente(Cod_Cli),
Constraint FK_Ped2 foreign key(Cod_Func) references Funcionario(Cod_Func),
Constraint CH_Ped check (Val_Ped >=0)
);



-- -----------------------------------------------------------------------------
-- 12

create table Titulo_Pedido
(
Num_Ped int not null,
Cod_Tit int not null,
Qtd_CD int not null,
Val_CD decimal (10,2) not null,
Constraint PK_TP primary key (Num_Ped, Cod_Tit),
Constraint FK_TP1 foreign key (Num_Ped) references Pedido (Num_Ped),
Constraint FK_TP2 foreign key (Cod_Tit) references Titulo (Cod_Tit),
Constraint CH_TP1 check (Qtd_CD >=1),
Constraint CH_TP2 check (Val_CD >0)
);


-- --------------------------------------------------------------------------
-- 13

create table Titulo_Artista
(
Cod_Tit int not null,
Cod_Art int not null,
Constraint PK_TA primary key (Cod_Tit, Cod_Art),
Constraint FK_TA1 foreign key (Cod_Tit) references Titulo (Cod_Tit),
Constraint FK_TA2 foreign key (Cod_Art) references Artista (Cod_Art)
);



-- ---------------------------------------------------------------------------

-- Inserts

-- -----------------------------------------------------
insert into artista values
(1,'Marisa Monte'),
(2,'Gilberto Gil'),
(3,'Caetano Veloso'),
(4,'Milton Nascimento'),
(5,'Legião Urbana'),
(6,'The Beatles'),
(7,'Rita Lee');
-- -----------------------------------------------------
insert into gravadora values
(1,'Polygram'),
(2,'EMI'),
(3,'Som Livre'),
(4,'Som Music');
-- -----------------------------------------------------
insert into categoria values
(1,'MPB'),(2,'Trilha Sonora'),
(3,'Rock Internacional'),(4,'Rock Nacional');
-- -----------------------------------------------------
insert into estado values
('SP','São Paulo'),('MG','Minas Gerais'),
('RJ','Rio de Janeiro'),('ES','Espirito Santo');
-- -----------------------------------------------------
insert into cidade values
(1,'SP','São Paulo'),
(2,'SP','Sorocaba'),
(3,'SP','Jundiaí'),
(4,'SP','Americana'),
(5,'SP','Araraquara'),
(6,'MG','Ouro Preto'),
(7,'ES','Cachoeiro de Itapemirim');
-- -----------------------------------------------------
insert into Cliente values (1,1,'José Nogueira','Rua A',1500.00,'F')
,(2,1,'Angelo Pereira','Rua B',2000.00,'M')
,(3,1,'Além Mar Paranhos','Rua C',1500.00,'F')
,(4,1,'Catarina Souza','Rua D',892.00,'F')
,(5,1,'Vagner Costa','Rua E',950.00,'F')
,(6,2,'Antenor da Costa','Rua F',1582.00,'M')
,(7,2,'Maria Amélia de Souza','Rua G',1152.00,'M')
,(8,2,'Paulo Roberto Silva','Rua H',3250.00,'M')
,(9,3,'Fátima Souza','Rua I',1632.00,'M')
,(10,3,'Joel da Rocha','Rua J',2000.00,'M');
-- -----------------------------------------------------
insert into Conjuge values
 (1,'Carla Nogueira',2500.00,'M'),
(2,'Emilia Pereira',5500.00,'F'),
(6,'Altiva da Costa',3000.00,'F'),
(7,'Carlos de Souza',3250.00,'M');
-- -----------------------------------------------------
insert into Funcionario values (1,'Vânia Gabriela Pereira','Rua A',2500.00,'F'),
(2,'Norberto Pereira da Silva','Rua B',300.00,'M'),
(3,'Olavo Linhares','Rua C',580.00,'M'),
(4,'Paula da Silva','Rua D',3000.00,'F'),
(5,'Rolando Rocha','Rua E',2000.00,'M');
-- -----------------------------------------------------
insert into Dependente values
(1,1,'Ana Pereira','F'),
(2,1,'Roberto Pereira','M'),
(3,1,'Celso Pereira','M'),
(4,3,'Brisa Linhares','F'),
(5,3,'Mari Sol Linhares','F'),
(6,4,'Sonia da Silva','F');
-- -----------------------------------------------------
insert into Titulo values (1,1,1,'Tribalistas',30.00,1500),
(2,1,2,'Tropicália',50.00,500),
(3,1,1,'Aquele Abraço',50.00,600),
(4,1,2,'Refazenda',60.00,1000),
(5,1,3,'Totalmente Demais',50.00,2000),
(6,1,3,'Travessia',55.00,500),
(7,1,2,'Courage',30.00,200),
(8,4,3,'Legião Urbana',30.00,100),
(9,3,2,'The Beatles',30.00,300),
(10,4,1,'Rita Lee',30.00,500);
-- -----------------------------------------------------
insert into Pedido values (1,1,2,'02/05/02',1500.00),
(2,3,4,'02/05/02',50.00),
(3,4,5,'02/06/02',100.00),
(4,1,4,'02/02/03',200.00),
(5,7,5,'02/03/03',300.00),
(6,4,4,'02/03/03',100.00),
(7,5,5,'02/03/03',50.00),
(8,8,2,'02/03/03',50.00),
(9,2,2,'02/03/03',2000.00),
(10,7,1,'02/03/03',3000.00);
-- -----------------------------------------------------
insert into Titulo_Artista values (1,1),
(2,2),(3,2),(4,2),(5,3),(6,4),(7,4),(8,5),(9,6),(10,7);
-- -----------------------------------------------------
insert into Titulo_Pedido values (1,1,2,30.00),
(1,2,3,20.00),
(2,1,1,50.00),
(2,2,3,30.00),
(3,1,2,40.00),
(4,2,3,20.00),
(5,1,2,25.00),
(6,2,3,30.00),
(6,3,1,35.00),
(7,4,2,55.00),
(8,1,4,60.00),
(9,2,3,15.00),
(10,7,2,15.00);

-- ------------------------------------------------------------------------------
-- Selects
