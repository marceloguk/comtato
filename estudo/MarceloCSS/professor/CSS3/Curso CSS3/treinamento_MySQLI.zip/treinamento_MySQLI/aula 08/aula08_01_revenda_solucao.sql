

use auto_sell;

-- 12) Traga uma lista dos carros no sistema, com o seu modelo, ano, placa e montadora.
select	montadoras.mon_nome as montadora, modelos.mod_nome as modelo,
		carros.car_ano as ano, carros.car_placa as placa
		from carros inner join modelos on carros.mod_id = modelos.mod_id
					inner join montadoras on montadoras.mon_id = modelos.mon_id
					order by 1 asc;

-- 13) Quais montadoras possuem carros � venda no sistema ?

select	distinct montadoras.mon_nome as Marca
		from carros
			inner join modelos on carros.mod_id = modelos.mod_id
			inner join montadoras on montadoras.mon_id = modelos.mon_id
			where carros.car_status = 'd';

select	montadoras.mon_nome as Marca
		from carros
			inner join modelos on carros.mod_id = modelos.mod_id
			inner join montadoras on montadoras.mon_id = modelos.mon_id
			where carros.car_status = 'd'
			group by montadoras.mon_nome;

-- 14) Qual dos nossos vendedores compra mais carros ?
select	vendedores.ven_nome as 'Nome do Vendedor',
	 -- transacoes.tran_tipo
    count(transacoes.tran_tipo) as 'Carros comprados'
		from  transacoes
					inner join vendedores on vendedores.ven_id = transacoes.ven_id
					where transacoes.tran_tipo = 'c'
					group by vendedores.ven_nome
					order by 2 desc;



select	vendedores.ven_nome as 'Nome do Vendedor',
	 -- transacoes.tran_tipo
    count(transacoes.tran_tipo) as 'Carros comprados'
		from  transacoes
					inner join vendedores on vendedores.ven_id = transacoes.ven_id
					where transacoes.tran_tipo = 'c'
					group by vendedores.ven_nome
					order by 2 desc LIMIT 0,2;



select    vendedores.ven_nome as 'Nome do Vendedor',
          count(transacoes.tran_tipo) as 'Carros comprados'
		from  transacoes
					inner join vendedores on vendedores.ven_id = transacoes.ven_id
					where transacoes.tran_tipo = 'c'
					group by vendedores.ven_nome
          HAVING COUNT(TRANSACOES.TRAN_TIPO) =
 (
          select	count(transacoes.tran_tipo)
		        from  transacoes
					inner join vendedores on vendedores.ven_id = transacoes.ven_id
					  where transacoes.tran_tipo = 'c'
					group by vendedores.ven_nome
					order by 1 desc LIMIT 0,1)
					order by 2 desc;



-- 15) De quem n�s j� compramos carros?
select	clientes.cli_nome as 'Nome do Cliente que vendeu o Carro'
		from  transacoes inner join clientes on clientes.cli_id = transacoes.cli_id
					where transacoes.tran_tipo = 'c'
					order by clientes.cli_nome asc;

-- Trazendo s� o nome do cliente

select	distinct clientes.cli_nome as 'Nome do Cliente que vendeu o Carro'
		from  transacoes inner join clientes on clientes.cli_id = transacoes.cli_id
					where transacoes.tran_tipo = 'c'
					order by clientes.cli_nome asc;


select	clientes.cli_nome as 'Nome do Cliente que vendeu o Carro'
		from  transacoes inner join clientes on clientes.cli_id = transacoes.cli_id 
					where transacoes.tran_tipo = 'c'
					group by clientes.cli_nome
					order by clientes.cli_nome asc;




-- Trazendo tamb�m o N�mero de carros vendidos

SELECT		clientes.cli_nome as 'Nome do Cliente que vendeu o Carro',
			    COUNT(clientes.cli_id) AS 'Num. de carros vendidos'
              FROM  transacoes
          INNER JOIN clientes ON transacoes.cli_id = clientes.cli_id
          WHERE     transacoes.tran_tipo = 'c'
          GROUP BY clientes.cli_nome;


SELECT		clientes.cli_nome as 'Nome do Cliente que vendeu o Carro',
			    COUNT(clientes.cli_id) AS 'Num. de carros vendidos'
              FROM  transacoes
          INNER JOIN     clientes ON transacoes.cli_id = clientes.cli_id
          GROUP BY clientes.cli_nome, transacoes.tran_tipo
          HAVING      transacoes.tran_tipo = 'c';



-- Uso do HAVING:

 --  WHERE valida antes do GROUP BY (vide 1� exemplo abaixo)
 --  HAVING valida ap�s o GROUP BY (vide 2� exemplo abaixo)


-- Erro:
SELECT    clientes.cli_nome as 'Nome do Cliente que vendeu o Carro',
			    COUNT(clientes.cli_id) AS 'Num. de carros vendidos'
              FROM  transacoes
      INNER JOIN  clientes ON transacoes.cli_id = clientes.cli_id
      WHERE  transacoes.tran_tipo = 'c' AND COUNT(clientes.cli_id) > 5 -- A cl�usula � validada ANTES do Agrupamento (GROUP BY)
      GROUP BY clientes.cli_nome
      ;


-- Acerto:
SELECT    clientes.cli_nome as 'Nome do Cliente que vendeu o Carro',
			    COUNT(clientes.cli_id) AS 'Num. de carros vendidos'
              FROM  transacoes
      INNER JOIN  clientes ON transacoes.cli_id = clientes.cli_id
      WHERE  transacoes.tran_tipo = 'c'
      GROUP BY clientes.cli_nome
      HAVING COUNT(clientes.cli_id) > 5; -- A cl�usula � validada AP�S o Agrupamento (GROUP BY)



















-- 16) Liste todos os carros da montadora FORD j� vendidos.
select	montadoras.mon_nome as Marca,
		modelos.mod_nome as Modelo,
		carros.car_placa as Placa,
		carros.car_ano as Ano,
		carros.car_venda as 'Valor de Venda'
		from carros
			inner join modelos on carros.mod_id = modelos.mod_id
			inner join montadoras on montadoras.mon_id = modelos.mon_id
			where carros.car_status = 'v' and montadoras.mon_nome like '%ford%';

-- 17) Liste todos os carros da montadora FERRARI � venda.
select	montadoras.mon_nome as Marca,
		modelos.mod_nome as Modelo,
		carros.car_placa as Placa,
		carros.car_ano as Ano
		from carros
			inner join modelos on carros.mod_id = modelos.mod_id
			inner join montadoras on montadoras.mon_id = modelos.mon_id
			 where carros.car_status = 'd' and montadoras.mon_nome like '%ferrari%'
			-- where carros.car_status = 'd' and montadoras.mon_nome = ' ferrari'   -- N�o Funciona por causa do espa�o antes do nome ferrari.
      ;


-- 18) Quantos carros foram vendidos at� o momento?
select	count(*) as 'Carros Vendidos' from transacoes where tran_tipo = 'v';

select	count(*) as 'Carros Vendidos' from carros where car_status = 'v';





-- ou, trazendo a data da consulta
select	count(*) as 'Carros Vendidos',
		current_date() as 'Data',
    current_time() as 'Hora',
    now()
		from transacoes where tran_tipo = 'v';


-- Tratamento de Data/ Hora


select	count(*) as 'Carros Vendidos',
    concat(day(now()), '/' , month(now()), '/' , year(now())) as data,
    date_format(now() , '%d/%m/%Y �s %H:%i' ) as data
		from transacoes where tran_tipo = 'v';



-- 19) Quantos clientes possuem restri��o de compra ?
	select count(*) from clientes where cli_status = 'c';


-- 20) Liste todos os carros (com o modelo) , definindo seu tipo de combust�vel por extenso (FLEX, Gasolina, etc).

select	montadoras.mon_nome as Marca,
		modelos.mod_nome as Modelo,
		carros.car_placa as Placa,
		carros.car_ano as Ano,
		case carros.car_combustivel
			when 'f' then 'Flex'
			when 'd' then 'Diesel'
			when 'g' then 'Gasolina'
			when 'a' then 'Alcool'
			when 'n' then 'G�s'
			end as Combust�vel
		from carros
			inner join modelos on carros.mod_id = modelos.mod_id
			inner join montadoras on montadoras.mon_id = modelos.mon_id
			;



-- 21) Liste todos os carros (com placa, modelo e Montadora) comprados de clientes que possuem restri��o em nosso sistema.

select	clientes.cli_nome as 'Nome do Cliente que vendeu o Carro',
		mod_nome as 'Modelo do Carro',
		mon_nome as 'Montadora',
		car_placa as Placa
		from carros inner join transacoes on carros.car_id = transacoes.car_id
					inner join clientes on clientes.cli_id = transacoes.cli_id
					inner join modelos on modelos.mod_id = carros.mod_id
					inner join montadoras on montadoras.mon_id = modelos.mon_id
					where transacoes.tran_tipo = 'c'
					and cli_status = 'c'
					order by clientes.cli_nome asc;


-- 22) Liste todos os carros (com placa, modelo e Montadora) j� vendidos.

select	mod_nome as 'Modelo do Carro',
		mon_nome as 'Montadora',
		car_placa as Placa
		from carros inner join modelos on modelos.mod_id = carros.mod_id
					inner join montadoras on montadoras.mon_id = modelos.mon_id
					where carros.car_status = 'v' ;


-- 23) Calcule qual a margem (%) de lucro na venda de cada carro j� vendido.

-- O C�lculo Bruto
select	car_placa as Placa,
		car_custo as 'Pre�o de Compra',
		car_venda as 'Pre�o de Venda' ,
		car_venda - car_custo as 'Lucro Bruto na venda',
		(car_venda - car_custo) * 100 / car_custo as 'Margem de Lucro'
		from carros where car_status = 'v';


-- A Margem de lucro bruto, correta.
select	car_placa as Placa,
		car_custo as 'Pre�o de Compra',
		car_venda as 'Pre�o de Venda' ,
		car_venda - car_custo as 'Lucro Bruto na venda',
		cast((car_venda - car_custo)/car_custo * 100 as dec (10,2)) as 'Margem de Lucro Bruta'
		from carros where car_status = 'v';




/*

	Regras de Neg�cios:

	Qdo ocorre uma venda, cada vendedor recebe 50% do lucro sobre o carro como
	comiss�o de venda.

	Ou seja, se um carro foi comprado por R$10.000,00 e vendido por R$15.000,00
	O vendedor t�m direito a R$ 2.500,00 de comiss�o.


	Baseando-se nisso, resolva abaixo:
*/


-- 24) Qto cada vendedor recebeu de comiss�o em cada venda ?

select	vendedores.ven_nome as 'Nome do Vendedor',
		carros.car_placa as Placa,
		carros.car_custo as 'Pre�o de Compra',
		carros.car_venda as 'Pre�o de Venda' ,
		carros.car_venda - carros.car_custo as 'Lucro Bruto na venda',
		(carros.car_venda - carros.car_custo) / carros.car_custo * 100 as 'Margem de Lucro',
		cast((carros.car_venda - carros.car_custo) / carros.car_custo * 100 as dec(5,2) ) as 'Margem de Lucro',
		cast((carros.car_venda - carros.car_custo)/2 as dec(8,2)) as 'Comiss�o do Vendedor'
		from carros join transacoes on carros.car_id = transacoes.car_id
					inner join vendedores on vendedores.ven_id = transacoes.ven_id 
		where carros.car_status = 'v' and transacoes.tran_tipo = 'v';



-- 25) Qto cada vendedor recebeu ao total ?
select	vendedores.ven_nome as 'Nome do Vendedor',
		sum((carros.car_venda - carros.car_custo)/2) as 'Comiss�o do Vendedor',
		cast(sum((carros.car_venda - carros.car_custo)/2) as dec(10,2)) as 'Comiss�o do Vendedor',
		concat( 'R$ ' , cast(sum((carros.car_venda - carros.car_custo)/2) as dec(10,2))) as 'Comiss�o do Vendedor'
		from carros inner join transacoes on carros.car_id = transacoes.car_id
					inner join vendedores on vendedores.ven_id = transacoes.ven_id
					where carros.car_status = 'v'
					and transacoes.tran_tipo = 'v'
					group by vendedores.ven_nome
					order by vendedores.ven_nome asc;













