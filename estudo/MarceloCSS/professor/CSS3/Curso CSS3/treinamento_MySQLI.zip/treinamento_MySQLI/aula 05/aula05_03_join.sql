﻿
drop database if exists familia;
create database familia;

use familia;

create table pai (

  pai_id    int          auto_increment  primary key,
  pai_nome  varchar(50)  not null

);

create table filho (

  fil_id    int          auto_increment primary key,
  fil_nome  varchar(50)  not null  unique,
  fil_sexo  char(1)      not null,
  pai_id    int,

constraint filho_pai foreign key (pai_id) references pai(pai_id)


);


create table mae (

  mae_id    int          auto_increment  primary key,
  mae_nome  varchar(50)  not null,
  pai_id    int,

constraint mae_pai foreign key (pai_id) references pai(pai_id)

);





insert into pai values (null , 'josé');
insert into pai values (null , 'joão');
insert into pai values (null , 'juca');


insert into filho values  (null , 'joazinho' , 'm' , 2) ,
                          (null , 'juquinha' , 'm' , 3) ,
                          (null , 'mariazinha' ,'f' , null);


insert into mae values (null , 'joana' , 2) , (null , 'josefa' , 1);


select * from pai;
select * from filho;
select * from mae;

SELECT * FROM information_schema.TABLE_CONSTRAINTS T where constraint_schema = 'familia';


select * from pai , filho where pai.pai_id = filho.pai_id;





/********************     INNER JOIN     ********************


INNER --> retorna todos os registros que obedeçam a uma regra de relacionamento definida pelo usuário.

	select * from TABELA1 inner join TABELA2 on tabela1.pk = tabela2.fk

*/


select * from pai inner join filho on pai.pai_id = filho.pai_id;
select * from pai p join filho f on p.pai_id = f.pai_id;

select p.pai_nome , f.fil_nome from pai p inner join filho f on p.pai_id = f.pai_id;

select * from filho f inner join pai p on p.pai_id = f.pai_id;








/********************     LEFT JOIN     ********************



LEFT --> Retorna todos os registros que obedeçam a uma regra de relacionamento (condição de associação)
		 que o usuário definir, mais todos os registros da tabela da esquerda, mesmo que não obedeçam à regra.


select * from TABELA1 left outer join TABELA2 on tabela1.pk = tabela2.fk

*/

select * from pai p left join filho f on p.pai_id = f.pai_id;
select * from pai p left outer join filho f on p.pai_id = f.pai_id;

-- Pais sem filhos
select * from pai p left join filho f on p.pai_id = f.pai_id where f.fil_id is null;






/********************     RIGHT JOIN     ********************

RIGHT --> Retorna todos os registros que obedeçam a uma regra de relacionamento (condição de associação)
		  que o usuário definir, mais todos os registros da tabela da direita, mesmo que não obedeçam à regra.


select * from TABELA1 right outer join TABELA2 on tabela1.pk = tabela2.fk

*/


select * from pai p right join filho f on p.pai_id = f.pai_id;
select * from pai p right outer join filho f on p.pai_id = f.pai_id;





/********************     CROSS JOIN     ********************


CROSS -->	Todos os dados, juntos em uma só consulta, sem nenhuma relação definida.
			Ou seja, cada linha da primeira tabela é relacionada com todas as linhas da segunda tabela.


		SELECT * FROM tabela1 CROSS JOIN tabela2

*/


select * from pai cross join filho ;
