﻿

-- 01) Crie um Database chamado Loja;

-- 02) Acesse o Database;

-- 03) Crie as tabelas definidas abaixo:

CATEGORIAS
  CAT_ID		int  		AI,PK
  CAT_NOME		varchar(50)

PRODUTOS
  PROD_ID		int  		AI, PK
  PROD_NOME		varchar(50)
  PROD_VALOR	decimal(8,2)
  CAT_ID		int, FK
  PAIS_ID		int, FK


UF
  UF_ID		int  	AI, PK
  UF_SIGLA	char(2)
  UF_NOME	varchar(20)
  PAIS_ID	int, FK



PAISES
  PAIS_ID		int  AI, PK
  PAIS_SIGLA	char(2)
  PAIS_NOME		varchar(50)


CLIENTES
  CLI_ID		int   AI, PK
  CLI_NOME		varchar(150)
  CLI_CPF		varchar(14)
  CID_ID    	int, FK
  CLI_SEXO		char(1)
  CLI_STATUS	char(1)


CIDADES
  CID_ID		int   AI, PK
  UF_ID			int	, FK
  CID_NOME		varchar(50)





INSERT INTO categorias VALUES ( null , 'monitores');
INSERT INTO categorias VALUES ( null ,  'computadores');
INSERT INTO categorias VALUES ( null , ' notebooks');
INSERT INTO categorias VALUES ( null , ' pen drives');
INSERT INTO categorias VALUES ( null , ' softwares');




INSERT INTO paises VALUES ( null , 'AF','Afghanistan');
INSERT INTO paises VALUES ( null , 'AL','Albania');
INSERT INTO paises VALUES ( null , 'DZ','Algeria');
INSERT INTO paises VALUES ( null , 'AS','American Samoa');
INSERT INTO paises VALUES ( null , 'AD','Andorra');
INSERT INTO paises VALUES ( null , 'AO','Angola');
INSERT INTO paises VALUES ( null , 'AI','Anguilla');
INSERT INTO paises VALUES ( null , 'AQ','Antarctica');
INSERT INTO paises VALUES ( null , 'AG','Antigua and Barbuda');
INSERT INTO paises VALUES ( null , 'AR','Argentina');
INSERT INTO paises VALUES ( null , 'AM','Armenia');
INSERT INTO paises VALUES ( null , 'AW','Aruba');
INSERT INTO paises VALUES ( null , 'AU','Australia');
INSERT INTO paises VALUES ( null , 'AT','Austria');
INSERT INTO paises VALUES ( null , 'AZ','Azerbaijan');
INSERT INTO paises VALUES ( null , 'BS','Bahamas');
INSERT INTO paises VALUES ( null , 'BH','Bahrain');
INSERT INTO paises VALUES ( null , 'BD','Bangladesh');
INSERT INTO paises VALUES ( null , 'BB','Barbados');
INSERT INTO paises VALUES ( null , 'BY','Belarus');
INSERT INTO paises VALUES ( null , 'BE','Belgium');
INSERT INTO paises VALUES ( null , 'BZ','Belize');
INSERT INTO paises VALUES ( null , 'BJ','Benin');
INSERT INTO paises VALUES ( null , 'BM','Bermuda');
INSERT INTO paises VALUES ( null , 'BT','Bhutan');
INSERT INTO paises VALUES ( null , 'BO','Bolivia');
INSERT INTO paises VALUES ( null , 'BA','Bosnia and Herzegovina');
INSERT INTO paises VALUES ( null , 'BW','Botswana');
INSERT INTO paises VALUES ( null , 'BV','Bouvet Island');
INSERT INTO paises VALUES ( null , 'BR','Brasil');
INSERT INTO paises VALUES ( null , 'IO','British Indian Ocean Territory');
INSERT INTO paises VALUES ( null , 'BN','Brunei Darussalam');
INSERT INTO paises VALUES ( null , 'BG','Bulgaria');
INSERT INTO paises VALUES ( null , 'BF','Burkina Faso');
INSERT INTO paises VALUES ( null , 'BI','Burundi');
INSERT INTO paises VALUES ( null , 'KH','Cambodia');
INSERT INTO paises VALUES ( null , 'CM','Cameroon');
INSERT INTO paises VALUES ( null , 'CA','Canada');
INSERT INTO paises VALUES ( null , 'CV','Cape Verde');
INSERT INTO paises VALUES ( null , 'KY','Cayman Islands');
INSERT INTO paises VALUES ( null , 'CF','Central African Republic');
INSERT INTO paises VALUES ( null , 'TD','Chad');
INSERT INTO paises VALUES ( null , 'CL','Chile');
INSERT INTO paises VALUES ( null , 'CN','China');
INSERT INTO paises VALUES ( null , 'CX','Christmas Island');
INSERT INTO paises VALUES ( null , 'CC','Cocos (Keeling) Islands');
INSERT INTO paises VALUES ( null , 'CO','Colombia');
INSERT INTO paises VALUES ( null , 'KM','Comoros');
INSERT INTO paises VALUES ( null , 'CG','Congo');
INSERT INTO paises VALUES ( null , 'CK','Cook Islands');
INSERT INTO paises VALUES ( null , 'CR','Costa Rica');
INSERT INTO paises VALUES ( null , 'CI','Cote dIvoire');
INSERT INTO paises VALUES ( null , 'HR','Croatia');
INSERT INTO paises VALUES ( null , 'CU','Cuba');
INSERT INTO paises VALUES ( null , 'CY','Cyprus');
INSERT INTO paises VALUES ( null , 'CZ','Czech Republic');
INSERT INTO paises VALUES ( null , 'DK','Denmark');
INSERT INTO paises VALUES ( null , 'DJ','Djibouti');
INSERT INTO paises VALUES ( null , 'DM','Dominica');
INSERT INTO paises VALUES ( null , 'DO','Dominican Republic');
INSERT INTO paises VALUES ( null , 'TP','East Timor');
INSERT INTO paises VALUES ( null , 'EC','Ecuador');
INSERT INTO paises VALUES ( null , 'EG','Egypt');
INSERT INTO paises VALUES ( null , 'SV','El Salvador');
INSERT INTO paises VALUES ( null , 'GQ','Equatorial Guinea');
INSERT INTO paises VALUES ( null , 'ER','Eritrea');
INSERT INTO paises VALUES ( null , 'EE','Estonia');
INSERT INTO paises VALUES ( null , 'ET','Ethiopia');
INSERT INTO paises VALUES ( null , 'FK','Falkland Islands (Malvinas)');
INSERT INTO paises VALUES ( null , 'FO','Faroe Islands');
INSERT INTO paises VALUES ( null , 'FJ','Fiji');
INSERT INTO paises VALUES ( null , 'FI','Finland');
INSERT INTO paises VALUES ( null , 'FR','France');
INSERT INTO paises VALUES ( null , 'FX','France, Metropolitan');
INSERT INTO paises VALUES ( null , 'GF','French Guiana');
INSERT INTO paises VALUES ( null , 'PF','French Polynesia');
INSERT INTO paises VALUES ( null , 'TF','French Southern Territories');
INSERT INTO paises VALUES ( null , 'GA','Gabon');
INSERT INTO paises VALUES ( null , 'GM','Gambia');
INSERT INTO paises VALUES ( null , 'GE','Georgia');
INSERT INTO paises VALUES ( null , 'DE','Germany');
INSERT INTO paises VALUES ( null , 'GH','Ghana');
INSERT INTO paises VALUES ( null , 'GI','Gibraltar');
INSERT INTO paises VALUES ( null , 'GR','Greece');
INSERT INTO paises VALUES ( null , 'GL','Greenland');
INSERT INTO paises VALUES ( null , 'GD','Grenada');
INSERT INTO paises VALUES ( null , 'GP','Guadeloupe');
INSERT INTO paises VALUES ( null , 'GU','Guam');
INSERT INTO paises VALUES ( null , 'GT','Guatemala');
INSERT INTO paises VALUES ( null , 'GN','Guinea');
INSERT INTO paises VALUES ( null , 'GW','Guinea-Bissau');
INSERT INTO paises VALUES ( null , 'GY','Guyana');
INSERT INTO paises VALUES ( null , 'HT','Haiti');
INSERT INTO paises VALUES ( null , 'HM','Heard Island and McDonald Islands');
INSERT INTO paises VALUES ( null , 'HN','Honduras');
INSERT INTO paises VALUES ( null , 'HK','Hong Kong');
INSERT INTO paises VALUES ( null , 'HU','Hungary');
INSERT INTO paises VALUES ( null , 'IS','Iceland');
INSERT INTO paises VALUES ( null , 'IN','India');
INSERT INTO paises VALUES ( null , 'ID','Indonesia');
INSERT INTO paises VALUES ( null , 'IR','Iran (Islamic Republic of)');
INSERT INTO paises VALUES ( null , 'IQ','Iraq');
INSERT INTO paises VALUES ( null , 'IE','Ireland');
INSERT INTO paises VALUES ( null , 'IL','Israel');
INSERT INTO paises VALUES ( null , 'IT','Italy');
INSERT INTO paises VALUES ( null , 'JM','Jamaica');
INSERT INTO paises VALUES ( null , 'JP','Japan');
INSERT INTO paises VALUES ( null , 'JO','Jordan');
INSERT INTO paises VALUES ( null , 'KZ','Kazakhstan');
INSERT INTO paises VALUES ( null , 'KE','Kenya');
INSERT INTO paises VALUES ( null , 'KI','Kiribati');
INSERT INTO paises VALUES ( null , 'KP','Korea, Democratic Peoples Republic of');
INSERT INTO paises VALUES ( null , 'KR','Korea, Republic of');
INSERT INTO paises VALUES ( null , 'KW','Kuwait');
INSERT INTO paises VALUES ( null , 'KG','Kyrgyzstan');
INSERT INTO paises VALUES ( null , 'LA','Lao Peoples Democratic Republic');
INSERT INTO paises VALUES ( null , 'LT','Latin America');
INSERT INTO paises VALUES ( null , 'LV','Latvia');
INSERT INTO paises VALUES ( null , 'LB','Lebanon');
INSERT INTO paises VALUES ( null , 'LS','Lesotho');
INSERT INTO paises VALUES ( null , 'LR','Liberia');
INSERT INTO paises VALUES ( null , 'LY','Libyan Arab Jamahiriya');
INSERT INTO paises VALUES ( null , 'LI','Liechtenstein');
INSERT INTO paises VALUES ( null , 'LX','Lithuania');
INSERT INTO paises VALUES ( null , 'LU','Luxembourg');
INSERT INTO paises VALUES ( null , 'MO','Macau');
INSERT INTO paises VALUES ( null , 'MK','Macedonia');
INSERT INTO paises VALUES ( null , 'MG','Madagascar');
INSERT INTO paises VALUES ( null , 'MW','Malawi');
INSERT INTO paises VALUES ( null , 'MY','Malaysia');
INSERT INTO paises VALUES ( null , 'MV','Maldives');
INSERT INTO paises VALUES ( null , 'ML','Mali');
INSERT INTO paises VALUES ( null , 'MT','Malta');
INSERT INTO paises VALUES ( null , 'MH','Marshall Islands');
INSERT INTO paises VALUES ( null , 'MQ','Martinique');
INSERT INTO paises VALUES ( null , 'MR','Mauritania');
INSERT INTO paises VALUES ( null , 'MU','Mauritius');
INSERT INTO paises VALUES ( null , 'YT','Mayotte');
INSERT INTO paises VALUES ( null , 'MX','Mexico');
INSERT INTO paises VALUES ( null , 'FM','Micronesia (Federated States of)');
INSERT INTO paises VALUES ( null , 'MD','Moldova, Republic of');
INSERT INTO paises VALUES ( null , 'MC','Monaco');
INSERT INTO paises VALUES ( null , 'MN','Mongolia');
INSERT INTO paises VALUES ( null , 'MS','Montserrat');
INSERT INTO paises VALUES ( null , 'MA','Morocco');
INSERT INTO paises VALUES ( null , 'MZ','Mozambique');
INSERT INTO paises VALUES ( null , 'MM','Myanmar');
INSERT INTO paises VALUES ( null , 'NA','Namibia');
INSERT INTO paises VALUES ( null , 'NR','Nauru');
INSERT INTO paises VALUES ( null , 'NP','Nepal');
INSERT INTO paises VALUES ( null , 'NL','Netherlands');
INSERT INTO paises VALUES ( null , 'AN','Netherlands Antilles');
INSERT INTO paises VALUES ( null , 'NC','New Caledonia');
INSERT INTO paises VALUES ( null , 'NZ','New Zealand');
INSERT INTO paises VALUES ( null , 'NI','Nicaragua');
INSERT INTO paises VALUES ( null , 'NE','Niger');
INSERT INTO paises VALUES ( null , 'NG','Nigeria');
INSERT INTO paises VALUES ( null , 'NU','Niue');
INSERT INTO paises VALUES ( null , 'NF','Norfolk Island');
INSERT INTO paises VALUES ( null , 'MP','Northern Mariana Islands');
INSERT INTO paises VALUES ( null , 'NO','Norway');
INSERT INTO paises VALUES ( null , 'OM','Oman');
INSERT INTO paises VALUES ( null , 'PK','Pakistan');
INSERT INTO paises VALUES ( null , 'PW','Palau');
INSERT INTO paises VALUES ( null , 'PA','Panama');
INSERT INTO paises VALUES ( null , 'PG','Papua New Guinea');
INSERT INTO paises VALUES ( null , 'PY','Paraguay');
INSERT INTO paises VALUES ( null , 'PE','Peru');
INSERT INTO paises VALUES ( null , 'PH','Philippines');
INSERT INTO paises VALUES ( null , 'PN','Pitcairn');
INSERT INTO paises VALUES ( null , 'PL','Poland');
INSERT INTO paises VALUES ( null , 'PT','Portugal');
INSERT INTO paises VALUES ( null , 'PR','Puerto Rico');
INSERT INTO paises VALUES ( null , 'QA','Qatar');
INSERT INTO paises VALUES ( null , 'RE','Reunion');
INSERT INTO paises VALUES ( null , 'RO','Romania');
INSERT INTO paises VALUES ( null , 'RU','Russian Federation');
INSERT INTO paises VALUES ( null , 'RW','Rwanda');
INSERT INTO paises VALUES ( null , 'SH','Saint Helena');
INSERT INTO paises VALUES ( null , 'KN','Saint Kitts and Nevis');
INSERT INTO paises VALUES ( null , 'LC','Saint Lucia');
INSERT INTO paises VALUES ( null , 'PM','Saint Pierre and Miquelon');
INSERT INTO paises VALUES ( null , 'VC','Saint Vincent and the Grenadines');
INSERT INTO paises VALUES ( null , 'WS','Samoa');
INSERT INTO paises VALUES ( null , 'SM','San Marino');
INSERT INTO paises VALUES ( null , 'ST','Sao Tome and Principe');
INSERT INTO paises VALUES ( null , 'SA','Saudi Arabia');
INSERT INTO paises VALUES ( null , 'SN','Senegal');
INSERT INTO paises VALUES ( null , 'SC','Seychelles');
INSERT INTO paises VALUES ( null , 'SL','Sierra Leone');
INSERT INTO paises VALUES ( null , 'SG','Singapore');
INSERT INTO paises VALUES ( null , 'SK','Slovakia');
INSERT INTO paises VALUES ( null , 'SI','Slovenia');
INSERT INTO paises VALUES ( null , 'SB','Solomon Islands');
INSERT INTO paises VALUES ( null , 'SO','Somalia');
INSERT INTO paises VALUES ( null , 'ZA','South Africa');
INSERT INTO paises VALUES ( null , 'GS','South Georgia and the South Sandwich Island');
INSERT INTO paises VALUES ( null , 'ES','Spain');
INSERT INTO paises VALUES ( null , 'LK','Sri Lanka');
INSERT INTO paises VALUES ( null , 'SD','Sudan');
INSERT INTO paises VALUES ( null , 'SR','Suriname');
INSERT INTO paises VALUES ( null , 'SJ','Svalbard and Jan Mayen Islands');
INSERT INTO paises VALUES ( null , 'SZ','Swaziland');
INSERT INTO paises VALUES ( null , 'SE','Sweden');
INSERT INTO paises VALUES ( null , 'CH','Switzerland');
INSERT INTO paises VALUES ( null , 'SY','Syrian Arab Republic');
INSERT INTO paises VALUES ( null , 'TW','Taiwan, Republic of China');
INSERT INTO paises VALUES ( null , 'TJ','Tajikistan');
INSERT INTO paises VALUES ( null , 'TZ','Tanzania, United Republic of');
INSERT INTO paises VALUES ( null , 'TH','Thailand');
INSERT INTO paises VALUES ( null , 'TG','Togo');
INSERT INTO paises VALUES ( null , 'TK','Tokelau');
INSERT INTO paises VALUES ( null , 'TO','Tonga');
INSERT INTO paises VALUES ( null , 'TT','Trinidad and Tobago');
INSERT INTO paises VALUES ( null , 'TN','Tunisia');
INSERT INTO paises VALUES ( null , 'TR','Turkey');
INSERT INTO paises VALUES ( null , 'TM','Turkmenistan');
INSERT INTO paises VALUES ( null , 'TC','Turks and Caicos Islands');
INSERT INTO paises VALUES ( null , 'TV','Tuvalu');
INSERT INTO paises VALUES ( null , 'UG','Uganda');
INSERT INTO paises VALUES ( null , 'UA','Ukraine');
INSERT INTO paises VALUES ( null , 'AE','United Arab Emirates');
INSERT INTO paises VALUES ( null , 'GB','United Kingdom');
INSERT INTO paises VALUES ( null , 'US','United States');
INSERT INTO paises VALUES ( null , 'UM','United States Minor Outlying Islands');
INSERT INTO paises VALUES ( null , 'UY','Uruguay');
INSERT INTO paises VALUES ( null , 'UZ','Uzbekistan');
INSERT INTO paises VALUES ( null , 'VU','Vanuatu');
INSERT INTO paises VALUES ( null , 'VA','Vatican City State (Holy See)');
INSERT INTO paises VALUES ( null , 'VE','Venezuela');
INSERT INTO paises VALUES ( null , 'VN','Viet Nam');
INSERT INTO paises VALUES ( null , 'VG','Virgin Islands (British)');
INSERT INTO paises VALUES ( null , 'VI','Virgin Islands (U.S.)');
INSERT INTO paises VALUES ( null , 'WF','Wallis and Futuna Islands');
INSERT INTO paises VALUES ( null , 'EH','Western Sahara');
INSERT INTO paises VALUES ( null , 'YE','Yemen');
INSERT INTO paises VALUES ( null , 'YU','Yugoslavia');
INSERT INTO paises VALUES ( null , 'ZR','Zaire');
INSERT INTO paises VALUES ( null , 'ZM','Zambia');
INSERT INTO paises VALUES ( null , 'ZW','Zimbabwe');




INSERT INTO produtos VALUES ( null , 'Sony Vaio', 5000.00, 3 , 30);
INSERT INTO produtos VALUES ( null , 'Apple Macbook', 3500.00, 3, 30);
INSERT INTO produtos VALUES ( null , 'Microsoft Office 2003', 500.00, 5, 30);
INSERT INTO produtos VALUES ( null , 'Apple Leopard OS', 200.00, 5, 30);
INSERT INTO produtos VALUES ( null , 'Sony Vault 8G', 340.60, 4, 30);
INSERT INTO produtos VALUES ( null , 'Sony Vault 16G', 910.30, 4, 30);
INSERT INTO produtos VALUES ( null , 'AOC 19', 980.00, 1, 30);
INSERT INTO produtos VALUES ( null , 'Dell Desktop ACT-5', 1900.00, 2, 30);
INSERT INTO produtos VALUES ( null , 'Kingston 2G', 80.00, 4, 30);
INSERT INTO produtos VALUES ( null , 'Kingston 1G', 40.00,4, 30);
INSERT INTO produtos VALUES ( null , 'Kingston 4G', 150.00,4, 30);
INSERT INTO produtos VALUES ( null , 'Kingston 8G', 300.00,4, 30);
INSERT INTO produtos VALUES ( null , 'Corsair 8G', 300.00,4, 30);
INSERT INTO produtos VALUES ( null , 'BlueSky 8G', 300.00,4, 30);
INSERT INTO produtos VALUES ( null , 'BlueSky 16G',910.30,4, 30);
INSERT INTO produtos VALUES ( null , 'Corsair 1G', 15.00,4, 30);
INSERT INTO produtos VALUES ( null , 'Corsair 4G', 100.00,4, 30);



INSERT INTO uf VALUES ( null , 'AC','Acre', 30);
INSERT INTO uf VALUES ( null , 'AL','Alagoas', 30);
INSERT INTO uf VALUES ( null , 'AM','Amazonas', 30);
INSERT INTO uf VALUES ( null , 'AP','Amapa', 30);
INSERT INTO uf VALUES ( null , 'BA','Bahia', 30);
INSERT INTO uf VALUES ( null , 'CE','Ceara', 30);
INSERT INTO uf VALUES ( null , 'DF','Distrito Federal', 30);
INSERT INTO uf VALUES ( null , 'ES','Espirito Santo', 30);
INSERT INTO uf VALUES ( null , 'GO','Goias', 30);
INSERT INTO uf VALUES ( null , 'MA','Maranhao', 30);
INSERT INTO uf VALUES ( null , 'MG','Minas Gerais', 30);
INSERT INTO uf VALUES ( null , 'MS','Mato Grosso do Sul', 30);
INSERT INTO uf VALUES ( null , 'MT','Mato Grosso', 30);
INSERT INTO uf VALUES ( null , 'PA','Para', 30);
INSERT INTO uf VALUES ( null , 'PB','Paraiba', 30);
INSERT INTO uf VALUES ( null , 'PE','Pernambuco', 30);
INSERT INTO uf VALUES ( null , 'PI','Piaui', 30);
INSERT INTO uf VALUES ( null , 'PR','Parana', 30);
INSERT INTO uf VALUES ( null , 'RJ','Rio de Janeiro', 30);
INSERT INTO uf VALUES ( null , 'RN','Rio Grande do Norte', 30);
INSERT INTO uf VALUES ( null , 'RO','Rondonia', 30);
INSERT INTO uf VALUES ( null , 'RR','Roraima', 30);
INSERT INTO uf VALUES ( null , 'RS','Rio Grande do Sul', 30);
INSERT INTO uf VALUES ( null , 'SC','Santa Catarina', 30);
INSERT INTO uf VALUES ( null , 'SE','Sergipe', 30);
INSERT INTO uf VALUES ( null , 'SP','Sao Paulo', 30);
INSERT INTO uf VALUES ( null , 'TO','Tocantins', 30);


INSERT INTO cidades VALUES ( null , 1,'ACRELANDIA');
INSERT INTO cidades VALUES ( null , 1,'ASSIS BRASIL');
INSERT INTO cidades VALUES ( null , 1,'BRASILEIA');
INSERT INTO cidades VALUES ( null , 1,'BUJARI');
INSERT INTO cidades VALUES ( null , 1,'CAPIXABA');
INSERT INTO cidades VALUES ( null , 2,'ANADIA');
INSERT INTO cidades VALUES ( null , 2,'ANEL');
INSERT INTO cidades VALUES ( null , 2,'ANUM NOVO');
INSERT INTO cidades VALUES ( null , 2,'ANUM VELHO');
INSERT INTO cidades VALUES ( null , 2,'ARAPIRACA');
INSERT INTO cidades VALUES ( null , 3,'ANAMA');
INSERT INTO cidades VALUES ( null , 3,'ANORI');
INSERT INTO cidades VALUES ( null , 3,'APUI');
INSERT INTO cidades VALUES ( null , 3,'ARIAU');
INSERT INTO cidades VALUES ( null , 3,'ATALAIA DO NORTE');
INSERT INTO cidades VALUES ( null , 4,'AGUA BRANCA DO AMAPARI');
INSERT INTO cidades VALUES ( null , 4,'AMAPA');
INSERT INTO cidades VALUES ( null , 4,'AMAPARI');
INSERT INTO cidades VALUES ( null , 4,'AMBE');
INSERT INTO cidades VALUES ( null , 4,'APOREMA');
INSERT INTO cidades VALUES ( null , 5,'ACUPE');
INSERT INTO cidades VALUES ( null , 5,'ADUSTINA');


INSERT INTO clientes VALUES ( null , 'Madalena Alves', '234.567.854-12' , 1, 'f', 'a');
INSERT INTO clientes VALUES ( null , 'Jose Kfouri Neto', '234.543.678-11' , 3, 'm', 'a');
INSERT INTO clientes VALUES ( null , 'Juca Kfouri Pai', '345.789.554-21' , 3, 'm', 'a');
INSERT INTO clientes VALUES ( null , 'Aline de Mello', '123.857.302-11' , 3, 'f', 'a');
INSERT INTO clientes VALUES ( null , 'Alves Barbosa', '591.765.921-01' , 7, 'm', 'a');
INSERT INTO clientes VALUES ( null , 'Eleonora de Lima', '462.825.969-46' , 4, 'f', 'a');
INSERT INTO clientes VALUES ( null , 'Zeca Santos', '462.514.275-97' , 8, 'm', 'i');
INSERT INTO clientes VALUES ( null , 'Daniela Silva Alves', '978.462.016-36' , 11, 'f', 'a');
INSERT INTO clientes VALUES ( null , 'Emiliano Art', '771.653.453-82' , 3, 'm', 'a');
INSERT INTO clientes VALUES ( null , 'Tatiana Limpo Campos', '278.665.867-56' , 22, 'f', 'a');




-- Query's:


-- 01) Selecione todas as categorias
-- 02) Traga o número total de Categorias
-- 03) Selecione todos os produtos
-- 04) Traga o produto + caro
-- 05) Traga os 5 produtos mais caros
-- 06) Selecione todos os produtos com custo abaixo de R$100
-- 07) Selecione todos os produtos com custo abaixo de R$100 (inclusive aqueles que custem R$100)
-- 08) Qtos produtos custam até R$100?
-- 09) Qtos produtos Kingston existem à venda ?
-- 10) Selecione todos os clientes
-- 11) Traga somente os nomes dos cliente em ordem alfabética
-- 12) Qtos clientes temos cadastrados, do sexo masculino.

-- 13) DESAFIO: Traga uma listagem com todos os clientes da cidade 'brasileia'
-- 14) DESAFIO: Liste todos os produtos e suas respectivas categorias. (pelo nome!)
-- 15) DESAFIO:  Liste todos os clientes, porém ao invés de trazer "F" ou "M" no  sexo, traga Masculino ou Feminino.


