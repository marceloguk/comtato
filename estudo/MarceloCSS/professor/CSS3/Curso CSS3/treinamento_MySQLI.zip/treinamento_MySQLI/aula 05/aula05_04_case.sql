
-- CASE


select * from filho;

select   fil_nome AS 'Nome do Filho(a)',
         fil_sexo AS 'Sexo'
      from filho;

-- Exemplo do CASE
select   fil_nome AS 'Nome do Filho(a)',
         case fil_sexo                  -- Abertura do CASE
            when 'f'  then 'Feminino'   -- When 'VALOR DA TABELA'   then   'TEXTO QUE IR� APARECER'
            when 'm'  then 'Masculino'
            else 'N�o Cadastrado'       -- else 'TEXTO QUE IR� APARECER CASO o VALOR N�O SEJA NENHUM DOS ANTERIORES'
         end AS 'Sexo'                  -- Fechamento do CASE (com o apelido da coluna logo em seguida)
      from filho;

select
      upper(fil_nome) 'Campo em letras Mai�sculas',
      fil_nome 'Campo Normal'
      from filho;

select
      fil_nome,
      fil_nome 'Campo Normal'
      from filho;
