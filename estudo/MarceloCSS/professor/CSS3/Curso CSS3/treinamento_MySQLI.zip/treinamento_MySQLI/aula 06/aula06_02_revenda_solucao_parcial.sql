


-- 01)	Qtos carros existem cadastrados no sistema?
select	count(*) as 'Qtd de carros' from carros ;

-- 02)	Qtos carros no estoque est�o � venda?
select	count(*) as 'N�m. de Carros � venda'  from carros where car_status = 'd' ;


-- 03)	Qual o valor (e somente o valor) do carro mais caro que j� compramos ?

-- Trazendo todos os valores
select car_custo from carros order by car_custo desc;

-- Em seguida, for�ando o Select a mostrar apenas o 1 resultado.
select car_custo from carros order by car_custo desc limit 0,1 ;

-- ou

select max(car_custo) 'Maior Valor pago em um carro' from carros;



-- 04)	Liste todos os carros no sistema, trazendo o Modelo e o ano do mesmo.

select * from carros;
select * from modelos;

select	modelos.mod_nome ,
		carros.car_ano
			from carros
	inner join modelos on modelos.mod_id = carros.mod_id ;


select	m.mod_nome 'Modelo',
		c.car_ano 'Ano'
			from carros c
	inner join modelos m on m.mod_id = c.mod_id ;

-- 05)	Liste todos os carros � venda no sistema, trazendo o Modelo, ano e o custo apenas
select	modelos.mod_nome as Modelo,carros.car_ano as Ano, carros.car_custo as Custo
		from carros inner join modelos on modelos.mod_id = carros.mod_id
		where car_status = 'd';


-- 06)	Qual o modelo e valor do carro mais caro que n�s j� compramos ?
select	modelos.mod_nome as Modelo, carros.car_custo as Valor
		from carros join modelos on modelos.mod_id = carros.mod_id
		order by car_custo desc limit 0,1     ;



select	modelos.mod_nome as Modelo, carros.car_custo as Valor
		from carros join modelos on modelos.mod_id = carros.mod_id
		where car_custo = ( select max(car_custo) from carros )
 ;

-- 07) Qtos clientes do estado de S�o Paulo est�o cadastrados no sistema?
--   PS: Monte a query de busca pelo nome do estado; e n�o pelo ID do estado.

select * from clientes;
select * from uf;

select	count(*) as 'N�mero de Clientes'
		from clientes inner join uf on clientes.uf_id = uf.uf_id
		where uf.uf_nome like '%S�o Paulo%'
 ;
