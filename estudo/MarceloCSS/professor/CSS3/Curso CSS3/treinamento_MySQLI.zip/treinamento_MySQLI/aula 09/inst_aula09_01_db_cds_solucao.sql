﻿

use db_cds;



-- Exercícios - Parte 1 :
	
  -- Exercícios com UNION


-- Traga, de cliente+conjuge+funcionario+dependente:

-- 01) lista de todos os nomes, sem repetição

select nome_func as 'nome' from funcionario
union
select nome_dep from dependente
union
select nome_cli from cliente
union
select nome_conj from conjuge
;

-- 02)	lista de todos os nomes, inclusive os repetidos

select nome_func as 'nome' from funcionario
union all
select nome_dep from dependente
union all 
select nome_cli from cliente
union all
select nome_conj from conjuge
;

-- 03)	lista de todos os nomes, mais uma coluna virtual com o nome da tabela de onde 'saíram', sem os repetidos

select nome_func as 'nome', 'funcionario' as 'tabela' from funcionario
union
select nome_dep, 'dependente' from dependente
union
select nome_cli, 'cliente' from cliente
union
select nome_conj, 'conjuge' from conjuge
order by tabela
;


-- Exercícios - Parte 2 :

  -- Exercício com SUBSELECT

-- 04)	lista de codigos de produtos (cod_tit) que nunca foram vendidos

select * from titulo;
select * from pedido;
select * from titulo_pedido;

select * from titulo where cod_tit not in ( select cod_tit from titulo_pedido)
;





  -- Exercícios com JOIN
-- 05)	pedidos de funcionario sem filho

select p.* , d.cod_dep , d.*
from pedido p
inner join funcionario f on p.cod_func = f.cod_func
left join dependente d on d.cod_func = f.cod_func
where d.cod_dep is null
;

-- 06)	pedidos de cliente solteiro

select p.*
from pedido p
inner join cliente c on p.cod_cli = c.cod_cli
left join conjuge x on x.cod_cli = c.cod_cli
where x.cod_cli is null
;

-- 07)	pedidos de cliente solteiro que comprou 'marisa monte'

select distinct p.*, c.*
from pedido p
inner join cliente c on p.cod_cli = c.cod_cli
left join conjuge x on x.cod_cli = c.cod_cli
inner join titulo_pedido tp on tp.num_ped = p.num_ped
inner join titulo t on t.cod_tit = tp.cod_tit
inner join titulo_artista ta on ta.cod_tit = tp.cod_tit
inner join artista a on a.cod_art = ta.cod_art
where x.cod_cli is null
	and a.nome_art = 'marisa monte'
;
-- 08)	pedidos de funcionario com filho, para cliente casado,
-- de produto com código menor ou igual a 5

select distinct p.*
from pedido p
inner join funcionario f on f.cod_func = p.cod_func
inner join dependente d on f.cod_func = d.cod_func
inner join cliente c on c.cod_cli = p.cod_cli
inner join conjuge x on c.cod_cli = x.cod_cli
inner join titulo_pedido tp on p.num_ped = tp.num_ped
where tp.cod_tit <= 5
;

-- 09)	pedidos de cliente casado atendido por funcionario que tem filho

select distinct p.*
from pedido p
inner join funcionario f on f.cod_func = p.cod_func
inner join dependente d on f.cod_func = d.cod_func
inner join cliente c on c.cod_cli = p.cod_cli
inner join conjuge x on c.cod_cli = x.cod_cli
;
-- 10)	pedidos de 'marisa monte', com nome do funcionario e nome do cliente

select  p.*, c.nome_cli, f.nome_func
from pedido p 
inner join cliente c on p.cod_cli = c.cod_cli 
inner join funcionario f on f.cod_func = p.cod_func
inner join titulo_pedido tp on tp.num_ped = p.num_ped
inner join titulo t on t.cod_tit = tp.cod_tit
inner join titulo_artista ta on ta.cod_tit = tp.cod_tit
inner join artista a on a.cod_art = ta.cod_art
where a.nome_art = 'marisa monte'
;
-- 11)	pedidos de titulos da gravadora 'emi'

select distinct p.*
from pedido p 
inner join titulo_pedido tp on tp.num_ped = p.num_ped
inner join titulo t on t.cod_tit = tp.cod_tit 
inner join gravadora g on g.cod_grav = t.cod_grav
where g.nome_grav = 'emi'
;

-- 12)	pedidos de mpb, exceto titulo começado com vogal, com nome do funcionario e nome do cliente e com o nome do conjuge e filhos, (se existirem)

select distinct t.nome_cd, p.num_ped, c.nome_cli, x.nome_conj,
              f.nome_func, d.nome_dep
from pedido p
inner join cliente c on p.cod_cli = c.cod_cli
left join conjuge x on c.cod_cli = x.cod_cli
inner join funcionario f on f.cod_func = p.cod_func
left join dependente d on f.cod_func = d.cod_func
inner join titulo_pedido tp on tp.num_ped = p.num_ped
inner join titulo t on t.cod_tit = tp.cod_tit
inner join categoria k on k.cod_cat = t.cod_cat
where k.nome_cat = 'mpb'
	and t.nome_cd not like 'a%'
	and t.nome_cd not like 'e%'
	and t.nome_cd not like 'i%'
	and t.nome_cd not like 'o%'
	and t.nome_cd not like 'u%'
	;




select distinct t.nome_cd, p.num_ped, c.nome_cli, x.nome_conj,
              f.nome_func, d.nome_dep
from pedido p
inner join cliente c on p.cod_cli = c.cod_cli
left join conjuge x on c.cod_cli = x.cod_cli
inner join funcionario f on f.cod_func = p.cod_func
left join dependente d on f.cod_func = d.cod_func
inner join titulo_pedido tp on tp.num_ped = p.num_ped
inner join titulo t on t.cod_tit = tp.cod_tit
inner join categoria k on k.cod_cat = t.cod_cat
where k.nome_cat = 'mpb'
	and substring(trim(t.nome_cd) , 1, 1) not regexp '[aeiou]';
