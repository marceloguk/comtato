CREATE DATABASE ESCOLA;

/*


  CREATE DATABASE xxxxx;

  Comando para Cria��o de um Database;


*/



USE ESCOLA;

/*

  USE xxxx:

  Serve para acessar o bando no qual ir�-se trabalhar;

*/




CREATE TABLE CURSOS (

      CODIGO  INT ,
      NOME  VARCHAR(50)

      );




/*


  CREATE TABLE xxxxxx (

        coluna 1  DATATYPE,
        coluna 2  DATATYPE
        ...
        ...
        ...
  );




*/

CREATE TABLE ALUNOS (

      CODIGO      INT,
      NOME        VARCHAR(50),
      NASCIMENTO  DATE
);




-- Insert Declarat�rio:
INSERT INTO CURSOS (CODIGO , NOME) VALUES ('1' , 'TRIC� I');

-- Insert Posicional:
INSERT INTO CURSOS VALUES ('2' , 'TRICO II');

-- Insert com NULL:
INSERT INTO CURSOS VALUES ( NULL , 'TRICO III');

-- Insert sem o INTO:
INSERT CURSOS VALUES ( NULL , 'PONTO CRUZ');

-- Insert sem aspas (vale somente para n�meros):
INSERT CURSOS VALUES (5 , 'CROCHE I');



SELECT * FROM CURSOS;


INSERT INTO ALUNOS VALUES (1 , 'JO�O' , '1970/5/25');


-- Insert M�ltiplo:
INSERT INTO ALUNOS VALUES (2 , 'JUCA' , '1977/12/4') ,
                          (3 , 'JOS�' , '1980/12/12') ,
                          (4 , 'JONAS' , '1970/10/4');


SELECT * FROM ALUNOS;

